// Lossless 4x4-tile replacement candidate for the frozen sc520_logo_pipeline.
// The generated map and dictionary preserve all 146x94 pixels and the
// index-zero transparency rule.  Input edge N still appears at edge N+3:
// tile address -> tile-map ROM -> dictionary ROM -> RGB mix/output.
`default_nettype none
module sc520_logo_tile4_pipeline #(
    parameter integer X_ORIGIN = 1008,
    parameter integer Y_ORIGIN = 32,
    parameter MAP_FILE = "assets/sc520-system-integration-i0304/anlogic_logo_tile4_map.mem",
    parameter DICT_FILE = "assets/sc520-system-integration-i0304/anlogic_logo_tile4_dict.mem"
) (
    input wire clk,
    input wire rst_n,
    input wire in_frame_start,
    input wire in_de,
    input wire in_hsync,
    input wire in_vsync,
    input wire in_mode,
    input wire [10:0] in_x,
    input wire [9:0] in_y,
    input wire [23:0] in_rgb,
    output reg out_frame_start,
    output reg out_de,
    output reg out_hsync,
    output reg out_vsync,
    output reg out_mode,
    output reg [10:0] out_x,
    output reg [9:0] out_y,
    output reg [23:0] out_rgb,
    output reg logo_active
);
    localparam integer LOGO_WIDTH = 146;
    localparam integer LOGO_HEIGHT = 94;
    localparam integer TILE_COLUMNS = 37;

    // 888x8 = 7104 bits and 3232x25 = 80800 bits.  At 20 Kib per
    // ERAM20K the two exact-depth memories require 1+4=5 blocks in theory.
    (* rom_style = "bram" *) reg [7:0] tile_map_rom [0:887];
    (* rom_style = "bram" *) reg [24:0] tile_dict_rom [0:3231];
    initial begin
        $readmemh(MAP_FILE, tile_map_rom);
        $readmemh(DICT_FILE, tile_dict_rom);
    end

    wire inside_logo = in_de && (in_x >= X_ORIGIN) &&
                       (in_x < X_ORIGIN + LOGO_WIDTH) &&
                       (in_y >= Y_ORIGIN) &&
                       (in_y < Y_ORIGIN + LOGO_HEIGHT);
    wire [10:0] offset_x = in_x - X_ORIGIN;
    wire [9:0] offset_y = in_y - Y_ORIGIN;
    wire [9:0] tile_x_extended = {4'd0, offset_x[7:2]};
    wire [9:0] tile_y_extended = {5'd0, offset_y[6:2]};
    // 37 = 32+4+1.  The largest valid address is 23*37+36 = 887.
    wire [9:0] tile_map_address = (tile_y_extended << 5) +
                                  (tile_y_extended << 2) +
                                  tile_y_extended + tile_x_extended;
    wire [3:0] pixel_in_tile = {offset_y[1:0], offset_x[1:0]};

    reg [9:0] s1_map_address;
    reg [3:0] s1_pixel;
    reg [7:0] s2_tile;
    reg [3:0] s2_pixel;
    reg [24:0] s3_word;
    // {frame_start, de, hsync, vsync, mode, x[10:0], y[9:0], rgb[23:0]}.
    reg [49:0] s1_video, s2_video, s3_video;
    reg s1_inside, s2_inside, s3_inside;
    reg s1_valid, s2_valid, s3_valid;

    // As in the frozen implementation, ROM-path registers are deliberately
    // not reset so the synthesis tool can absorb them into synchronous ERAM.
    // Reset gates the video/valid path, so stale ROM values cannot escape.
    always @(posedge clk) begin
        s1_map_address <= inside_logo ? tile_map_address : 10'd0;
        s1_pixel <= inside_logo ? pixel_in_tile : 4'd0;
        s2_tile <= tile_map_rom[s1_map_address];
        s2_pixel <= s1_pixel;
        s3_word <= tile_dict_rom[{s2_tile, s2_pixel}];
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_video <= 50'd0;
            s2_video <= 50'd0;
            s3_video <= 50'd0;
            s1_inside <= 1'b0;
            s2_inside <= 1'b0;
            s3_inside <= 1'b0;
            s1_valid <= 1'b0;
            s2_valid <= 1'b0;
            s3_valid <= 1'b0;
            {out_frame_start, out_de, out_hsync, out_vsync, out_mode,
             out_x, out_y, out_rgb, logo_active} <= 51'd0;
        end else begin
            s1_video <= {in_frame_start, in_de, in_hsync, in_vsync, in_mode,
                         in_x, in_y, in_rgb};
            s2_video <= s1_video;
            s3_video <= s2_video;
            s1_inside <= inside_logo;
            s2_inside <= s1_inside;
            s3_inside <= s2_inside;
            s1_valid <= 1'b1;
            s2_valid <= s1_valid;
            s3_valid <= s2_valid;

            if (s3_valid) begin
                {out_frame_start, out_de, out_hsync, out_vsync, out_mode,
                 out_x, out_y} <= s3_video[49:24];
                out_rgb <= !s3_video[48] ? 24'd0 :
                           (s3_inside && s3_word[24]) ? s3_word[23:0] :
                           s3_video[23:0];
                logo_active <= s3_video[48] && s3_inside && s3_word[24];
            end else begin
                {out_frame_start, out_de, out_hsync, out_vsync, out_mode,
                 out_x, out_y, out_rgb, logo_active} <= 51'd0;
            end
        end
    end

    // synthesis translate_off
    initial begin
        if (X_ORIGIN < 0 || X_ORIGIN > 2047 || Y_ORIGIN < 0 || Y_ORIGIN > 1023)
            $fatal(1, "sc520_logo_tile4_pipeline invalid origin");
    end
    // synthesis translate_on
endmodule
`default_nettype wire
