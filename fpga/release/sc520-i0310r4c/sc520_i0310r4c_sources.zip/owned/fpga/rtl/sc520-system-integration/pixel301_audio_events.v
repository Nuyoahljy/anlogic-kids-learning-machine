// One pending business event. New context cancels the old stream immediately.
// Only the twenty events in shape3-cards5-v1 can reach the compatible 32-slot PAK.
module pixel301_audio_events(
    input wire clk,rst_n,recover,cancel,event_valid,
    input wire [2:0] event_kind,input wire [3:0] event_item,
    input wire player_ready,player_busy,player_fault,
    output wire play,output wire player_cancel,output wire [4:0] clip_index,
    output wire audio_idle,output wire audio_fault,
    output reg invalid_event
);
    reg pending;
    reg [4:0] selected;
    reg [4:0] mapped;
    reg legal;
    always @* begin
        mapped=0;legal=1;
        case(event_kind)
            1,2:begin
                if((event_item>=1&&event_item<=3)||(event_item>=10&&event_item<=14))
                    mapped=event_item-1+(event_kind==2?14:0);
                else legal=0;
            end
            3:mapped=28;
            4:mapped=29;
            6:mapped=30;
            7:mapped=31;
            default:legal=0;
        endcase
    end
    assign player_cancel=cancel||recover||event_valid;
    assign play=pending&&player_ready&&!player_fault&&!player_cancel;
    assign clip_index=selected;
    assign audio_idle=!pending&&!player_busy;
    assign audio_fault=player_fault||invalid_event;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin pending<=0;selected<=0;invalid_event<=0;end
        else if(recover)begin pending<=0;selected<=0;invalid_event<=0;end
        else if(cancel)pending<=0;
        else if(event_valid)begin
            pending<=legal&&!player_fault;
            if(legal)selected<=mapped;else invalid_event<=1;
        end else if(player_fault||play)pending<=0;
endmodule
