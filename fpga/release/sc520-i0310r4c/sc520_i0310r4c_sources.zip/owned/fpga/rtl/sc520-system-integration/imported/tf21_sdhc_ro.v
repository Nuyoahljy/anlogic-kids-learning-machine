`timescale 1ns/1ps
// SD v2 high-capacity SPI only. No write, erase, CMD16 or raw-card writes.
module tf21_sdhc_ro #(
    parameter integer POWER_CYCLES=750000,
    parameter integer INIT_TIMEOUT_CYCLES=225000000,
    parameter integer TOKEN_LIMIT=65535,
    parameter integer INIT_HALF=96,
    parameter integer WORK_HALF=3
) (
    input wire clk,rst_n,recover,
    input wire read_valid,
    input wire [31:0] read_lba,
    output wire read_ready,
    output reg initialized,fault,
    output reg [3:0] error_code,
    output reg data_valid,
    output reg [8:0] data_index,
    output reg [7:0] data_byte,
    output reg read_done,
    output reg sd_cs_n,
    output wire sd_sck,sd_mosi,
    input wire sd_miso
);
    localparam POWER=0,CLOCKS=1,GAP=2,SEND=3,RESP=4,EXT=5,
        TOKEN=6,DATA=7,CRC=8,FINISH=9,DISPATCH=10,IDLE=11,FAILED=12;
    reg [3:0] state;
    reg [2:0] operation;
    reg [31:0] counter,init_age,arg,extra;
    reg [3:0] byte_index;
    reg [7:0] response;
    reg waiting,io_start;
    reg [7:0] io_tx;
    wire io_busy,io_done;
    wire [7:0] io_rx;
    wire [7:0] half_period=initialized ? WORK_HALF : INIT_HALF;
    reg [8:0] payload_index;
    reg crc_index;
    wire [5:0] command=operation==0?0:operation==1?8:operation==2?55:operation==3?41:operation==4?58:17;
    wire [31:0] command_arg=operation==1?32'h1aa:operation==3?32'h40000000:operation==5?arg:0;
    wire [7:0] command_byte=byte_index==0?{2'b01,command}:
        byte_index==1?command_arg[31:24]:byte_index==2?command_arg[23:16]:
        byte_index==3?command_arg[15:8]:byte_index==4?command_arg[7:0]:
        operation==0?8'h95:operation==1?8'h87:8'h01;
    assign read_ready=initialized && !fault && state==IDLE;
    tf21_spi_byte spi(.clk(clk),.rst_n(rst_n&&!recover),.start(io_start),.tx(io_tx),
        .half_period(half_period),.miso(sd_miso),.sck(sd_sck),.mosi(sd_mosi),
        .busy(io_busy),.done(io_done),.rx(io_rx));
    task fail;
        input [3:0] code;
        begin state<=FAILED;fault<=1;initialized<=0;sd_cs_n<=1;error_code<=code;end
    endtask
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin
            state<=POWER;operation<=0;counter<=0;init_age<=0;arg<=0;extra<=0;
            byte_index<=0;response<=0;waiting<=0;io_start<=0;io_tx<=8'hff;
            initialized<=0;fault<=0;error_code<=0;data_valid<=0;data_index<=0;
            data_byte<=0;read_done<=0;sd_cs_n<=1;payload_index<=0;crc_index<=0;
        end else if(recover)begin
            state<=POWER;operation<=0;counter<=0;init_age<=0;waiting<=0;io_start<=0;
            initialized<=0;fault<=0;error_code<=0;sd_cs_n<=1;data_valid<=0;read_done<=0;
            byte_index<=0;extra<=0;payload_index<=0;crc_index<=0;
        end else begin
            io_start<=0;data_valid<=0;read_done<=0;
            if(!initialized && !fault)begin
                if(init_age==INIT_TIMEOUT_CYCLES-1)fail(1);
                else init_age<=init_age+1'b1;
            end
            if(initialized || fault || init_age!=INIT_TIMEOUT_CYCLES-1)begin
                case(state)
                    POWER:if(counter==POWER_CYCLES-1)begin counter<=0;state<=CLOCKS;end else counter<=counter+1'b1;
                    CLOCKS,GAP,FINISH:begin
                        sd_cs_n<=1;
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;
                            if(state==CLOCKS)begin
                                if(counter==9)begin counter<=0;state<=GAP;end else counter<=counter+1'b1;
                            end else if(state==GAP)begin sd_cs_n<=0;byte_index<=0;state<=SEND;end
                            else state<=DISPATCH;
                        end
                    end
                    SEND:begin
                        if(!waiting)begin io_start<=1;io_tx<=command_byte;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;
                            if(byte_index==5)begin counter<=0;state<=RESP;end else byte_index<=byte_index+1'b1;
                        end
                    end
                    RESP:begin
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;
                            if(!io_rx[7])begin
                                response<=io_rx;
                                if((operation==1 && io_rx==1)||(operation==4 && io_rx==0))begin byte_index<=0;extra<=0;state<=EXT;end
                                else if(operation==5 && io_rx==0)begin counter<=0;state<=TOKEN;end
                                else state<=FINISH;
                            end else if(counter==15)fail(2);
                            else counter<=counter+1'b1;
                        end
                    end
                    EXT:begin
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;extra<={extra[23:0],io_rx};
                            if(byte_index==3)state<=FINISH;else byte_index<=byte_index+1'b1;
                        end
                    end
                    TOKEN:begin
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;
                            if(io_rx==8'hfe)begin payload_index<=0;state<=DATA;end
                            else if(io_rx!=8'hff)fail(3);
                            else if(counter==TOKEN_LIMIT-1)fail(4);
                            else counter<=counter+1'b1;
                        end
                    end
                    DATA:begin
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin
                            waiting<=0;data_valid<=1;data_index<=payload_index;data_byte<=io_rx;
                            if(payload_index==511)begin state<=CRC;crc_index<=0;end else payload_index<=payload_index+1'b1;
                        end
                    end
                    CRC:begin
                        if(!waiting)begin io_start<=1;io_tx<=8'hff;waiting<=1;end
                        else if(io_done)begin waiting<=0;if(crc_index)state<=FINISH;else crc_index<=1;end
                    end
                    DISPATCH:begin
                        case(operation)
                            0:if(response==1)begin operation<=1;state<=GAP;end else fail(5);
                            1:if(response==1 && extra==32'h1aa)begin operation<=2;state<=GAP;end else fail(6);
                            2:if(response==1)begin operation<=3;state<=GAP;end else fail(7);
                            3:if(response==1)begin operation<=2;state<=GAP;end else if(response==0)begin operation<=4;state<=GAP;end else fail(7);
                            4:if(response==0 && extra[31:30]==2'b11 && (extra[23:15]!=0))begin initialized<=1;state<=IDLE;end else fail(8);
                            5:if(response==0)begin read_done<=1;state<=IDLE;end else fail(9);
                            default:fail(15);
                        endcase
                    end
                    IDLE:if(read_valid)begin arg<=read_lba;operation<=5;state<=GAP;end
                    default:begin end
                endcase
            end
        end
endmodule
