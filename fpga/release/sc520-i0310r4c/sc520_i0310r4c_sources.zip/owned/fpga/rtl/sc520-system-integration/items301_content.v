module items301_content(
    input wire [2:0] line_index,input wire [5:0] char_index,
    input wire [1:0] mode,phase,style_mode,cal_state,tf_state,
    input wire [3:0] score,question_index,target_item,display_item,
    input wire [2:0] feedback,
    input wire source_test,armed,audio_fault,audio_busy,result_healthy,
    output reg [7:0] glyph,output reg [1:0] tone
);
    wire [7:0] base_glyph;wire [1:0] base_tone;
    items30_content original(.line_index(line_index),.char_index(char_index),.mode(mode),.phase(phase),
        .score(score),.question_index(question_index),.target_item(target_item),.display_item(display_item),
        .feedback(feedback),.source_test(source_test),.armed(armed),.audio_fault(audio_fault),
        .audio_busy(audio_busy),.result_healthy(result_healthy),.display_mode(1'b0),.glyph(base_glyph),.tone(base_tone));
function [7:0] ui_text;input [3:0] text_id;input [5:0] column;begin ui_text=0;case({text_id,column})
10'd0:ui_text=8'd173;
10'd1:ui_text=8'd170;
10'd2:ui_text=8'd120;
10'd64:ui_text=8'd169;
10'd65:ui_text=8'd167;
10'd128:ui_text=8'd26;
10'd129:ui_text=8'd175;
10'd192:ui_text=8'd173;
10'd193:ui_text=8'd170;
10'd194:ui_text=8'd120;
10'd256:ui_text=8'd129;
10'd257:ui_text=8'd74;
10'd258:ui_text=8'd171;
10'd259:ui_text=8'd166;
10'd320:ui_text=8'd171;
10'd321:ui_text=8'd166;
10'd322:ui_text=8'd168;
10'd323:ui_text=8'd162;
10'd324:ui_text=8'd161;
10'd384:ui_text=8'd168;
10'd385:ui_text=8'd162;
10'd386:ui_text=8'd38;
10'd387:ui_text=8'd63;
10'd448:ui_text=8'd168;
10'd449:ui_text=8'd162;
10'd450:ui_text=8'd164;
10'd451:ui_text=8'd174;
10'd512:ui_text=8'd160;
10'd513:ui_text=8'd159;
10'd514:ui_text=8'd162;
10'd515:ui_text=8'd163;
10'd516:ui_text=8'd161;
10'd576:ui_text=8'd160;
10'd577:ui_text=8'd159;
10'd578:ui_text=8'd165;
10'd579:ui_text=8'd172;
10'd640:ui_text=8'd160;
10'd641:ui_text=8'd159;
10'd642:ui_text=8'd72;
10'd643:ui_text=8'd74;
10'd644:ui_text=8'd161;
10'd704:ui_text=8'd160;
10'd705:ui_text=8'd159;
10'd706:ui_text=8'd75;
10'd707:ui_text=8'd141;
10'd768:ui_text=8'd1;
10'd769:ui_text=8'd49;
10'd770:ui_text=8'd93;
10'd771:ui_text=8'd44;
10'd773:ui_text=8'd1;
10'd774:ui_text=8'd50;
10'd775:ui_text=8'd136;
10'd776:ui_text=8'd72;
10'd778:ui_text=8'd1;
10'd779:ui_text=8'd51;
10'd780:ui_text=8'd131;
10'd781:ui_text=8'd146;
10'd783:ui_text=8'd1;
10'd784:ui_text=8'd52;
10'd785:ui_text=8'd99;
10'd786:ui_text=8'd20;
10'd832:ui_text=8'd39;
10'd833:ui_text=8'd80;
10'd834:ui_text=8'd71;
10'd835:ui_text=8'd13;
10'd836:ui_text=8'd105;
10'd837:ui_text=8'd143;
default:ui_text=0;endcase end endfunction
    always @*begin
        glyph=base_glyph;tone=base_tone;
        if(line_index==1&&!source_test&&char_index<24)glyph=ui_text(4'd13,char_index);
        if(line_index==1&&char_index>=24)glyph=ui_text({2'd0,style_mode},char_index-24);
        if(line_index==2)begin
            glyph=char_index<12?ui_text(4'd4+cal_state,char_index):char_index>=14?ui_text(4'd8+tf_state,char_index-14):8'd0;
            tone=(cal_state==3||tf_state==3)?2'd2:2'd1;
        end
        if(line_index==4&&(mode==0||mode==1)&&result_healthy&&!source_test)glyph=ui_text(4'd12,char_index);
    end
endmodule
