`timescale 1ns/1ps
// Independent v2: BOOT qualification is staged; sector/file interfaces unchanged.
module tf21_fat32_file #(
    parameter integer IO_TIMEOUT_CYCLES=15000000,
    parameter [31:0] MOUNT_TIMEOUT_CYCLES=32'd2250000000,
    parameter integer MAX_CHAIN_HOPS=65536
) (
    input wire clk,rst_n,recover,card_ready,card_fault,
    output reg sd_req,
    output reg [31:0] sd_lba,
    input wire sd_ready,sd_done,sd_data_valid,
    input wire [8:0] sd_data_index,
    input wire [7:0] sd_data,
    input wire file_req,
    input wire [31:0] file_sector,
    output wire file_ready,
    output reg mounted,fault,
    output reg [3:0] error_code,
    output reg [31:0] file_size,
    output reg file_data_valid,file_done,
    output reg [8:0] file_data_index,
    output reg [7:0] file_data
);
    localparam WAIT_CARD=0,REQUEST=1,IO=2,AFTER0=3,AFTERBOOT=4,ROOT=5,AFTERROOT=6,
        AFTERFATROOT=7,IDLE=8,MAPFILE=9,AFTERFATFILE=10,AFTERFILE=11,FAILED=12,
        VERIFYROOT=13,AFTERVERIFYROOT=14,VERIFYFILE=15,AFTERVERIFYFILE=16,
        CALC_A=17,CALC_B=18,CALC_C=19,CALC_D=20;
    localparam BOOT=0,DIR=1,FAT=2,FILEDATA=3;
    reg [4:0] state,after_state,boot_continuation;
    reg [1:0] parse_mode;
    reg [31:0] age,partition,partition_size,reserved,fat_size,total_sectors,root_cluster;
    reg [31:0] mount_age;
    reg [15:0] bps,root_entries,total16,fat16,extflags,fsver,signature;
    reg [7:0] spc,fat_count;
    reg [31:0] mbr_start[0:3],mbr_size[0:3];
    reg [7:0] mbr_type[0:3];
    reg [31:0] volume_clusters,fat_base,data_base;
    reg [2:0] spc_shift;
    reg [31:0] root_current,root_offset,root_hops;
    reg [31:0] file_first,cache_cluster,cache_index,target_cluster,target_sector,hops;
    reg [31:0] fat_value,verify_cluster,verify_left,verify_hops;
    reg [8:0] fat_offset;
    reg [255:0] entry;
    wire [255:0] entry_complete={sd_data,entry[247:0]};
    reg found,dir_end;
    reg [31:0] found_cluster,found_size;
    integer k;
    reg [2:0] decoded_shift,computed_shift;
    reg raw_boot_ok,boot_qualified;
    reg [63:0] fat_span_wide,active_fat_wide,fat_relative_wide,fat_capacity_wide;
    reg [63:0] data_offset_wide,cluster_count_wide,fat_base_wide,data_base_wide,volume_end_wide;
    always @* begin
        case(spc)
            1:decoded_shift=0;2:decoded_shift=1;4:decoded_shift=2;8:decoded_shift=3;
            16:decoded_shift=4;32:decoded_shift=5;64:decoded_shift=6;128:decoded_shift=7;
            default:decoded_shift=0;
        endcase
    end
    assign file_ready=state==IDLE && mounted && !fault;
    task fail;
        input [3:0] code;
        begin fault<=1;mounted<=0;error_code<=code;state<=FAILED;sd_req<=0;end
    endtask
    task read_sector;
        input [31:0] lba;
        input [1:0] mode;
        input [4:0] continuation;
        begin
            sd_lba<=lba;parse_mode<=mode;after_state<=mode==BOOT?CALC_A:continuation;
            state<=REQUEST;age<=0;
            if(mode==BOOT)begin
                boot_continuation<=continuation;boot_qualified<=0;raw_boot_ok<=0;
                bps<=0;spc<=0;reserved<=0;fat_count<=0;root_entries<=0;total16<=0;
                fat16<=0;total_sectors<=0;fat_size<=0;extflags<=0;fsver<=0;root_cluster<=0;signature<=0;
                for(k=0;k<4;k=k+1)begin mbr_start[k]<=0;mbr_size[k]<=0;mbr_type[k]<=0;end
            end
            if(mode==DIR)begin entry<=0;found<=0;dir_end<=0;end
            if(mode==FAT)fat_value<=0;
        end
    endtask
    task read_fat;
        input [31:0] cluster;
        input [4:0] continuation;
        begin fat_offset<={cluster[6:0],2'b00};read_sector(fat_base+(cluster>>7),FAT,continuation);end
    endtask
    wire fat_next_ok=fat_value[27:0]>=2 && fat_value[27:0]<volume_clusters+2 && fat_value[27:0]<28'hffffff0;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin
            state<=WAIT_CARD;after_state<=0;boot_continuation<=0;parse_mode<=0;age<=0;mount_age<=0;partition<=0;partition_size<=0;
            sd_req<=0;sd_lba<=0;mounted<=0;fault<=0;error_code<=0;file_size<=0;
            file_data_valid<=0;file_data_index<=0;file_data<=0;file_done<=0;
            reserved<=0;fat_size<=0;total_sectors<=0;root_cluster<=0;bps<=0;root_entries<=0;
            total16<=0;fat16<=0;extflags<=0;fsver<=0;signature<=0;spc<=0;fat_count<=0;
            volume_clusters<=0;fat_base<=0;data_base<=0;spc_shift<=0;
            root_current<=0;root_offset<=0;root_hops<=0;file_first<=0;cache_cluster<=0;
            cache_index<=0;target_cluster<=0;target_sector<=0;hops<=0;
            fat_value<=0;fat_offset<=0;entry<=0;found<=0;dir_end<=0;found_cluster<=0;found_size<=0;
            verify_cluster<=0;verify_left<=0;verify_hops<=0;
            raw_boot_ok<=0;boot_qualified<=0;
            computed_shift<=0;fat_span_wide<=0;active_fat_wide<=0;fat_relative_wide<=0;fat_capacity_wide<=0;
            data_offset_wide<=0;cluster_count_wide<=0;fat_base_wide<=0;data_base_wide<=0;volume_end_wide<=0;
            for(k=0;k<4;k=k+1)begin mbr_start[k]<=0;mbr_size[k]<=0;mbr_type[k]<=0;end
        end else if(recover)begin
            state<=WAIT_CARD;sd_req<=0;mounted<=0;fault<=0;error_code<=0;partition<=0;
            partition_size<=0;file_size<=0;file_data_valid<=0;file_done<=0;age<=0;mount_age<=0;
            boot_qualified<=0;raw_boot_ok<=0;boot_continuation<=0;computed_shift<=0;
            fat_span_wide<=0;active_fat_wide<=0;fat_relative_wide<=0;fat_capacity_wide<=0;
            data_offset_wide<=0;cluster_count_wide<=0;fat_base_wide<=0;data_base_wide<=0;volume_end_wide<=0;
        end else begin
            sd_req<=0;file_data_valid<=0;file_done<=0;
            if(!mounted&&card_ready&&!fault)mount_age<=mount_age+1'b1;
            if(card_fault)fail(1);
            else if(!mounted&&card_ready&&mount_age==MOUNT_TIMEOUT_CYCLES-1)fail(11);
            else if((state==REQUEST||state==IO)&&age==IO_TIMEOUT_CYCLES-1)fail(2);
            else begin
                if(state==REQUEST||state==IO)age<=age+1'b1;
                if(state==IO && sd_data_valid)begin
                    case(parse_mode)
                        BOOT:begin
                            if(sd_data_index>=11&&sd_data_index<13)bps[(sd_data_index-11)*8+:8]<=sd_data;
                            if(sd_data_index==13)spc<=sd_data;
                            if(sd_data_index>=14&&sd_data_index<16)reserved[(sd_data_index-14)*8+:8]<=sd_data;
                            if(sd_data_index==16)fat_count<=sd_data;
                            if(sd_data_index>=17&&sd_data_index<19)root_entries[(sd_data_index-17)*8+:8]<=sd_data;
                            if(sd_data_index>=19&&sd_data_index<21)total16[(sd_data_index-19)*8+:8]<=sd_data;
                            if(sd_data_index>=22&&sd_data_index<24)fat16[(sd_data_index-22)*8+:8]<=sd_data;
                            if(sd_data_index>=32&&sd_data_index<36)total_sectors[(sd_data_index-32)*8+:8]<=sd_data;
                            if(sd_data_index>=36&&sd_data_index<40)fat_size[(sd_data_index-36)*8+:8]<=sd_data;
                            if(sd_data_index>=40&&sd_data_index<42)extflags[(sd_data_index-40)*8+:8]<=sd_data;
                            if(sd_data_index>=42&&sd_data_index<44)fsver[(sd_data_index-42)*8+:8]<=sd_data;
                            if(sd_data_index>=44&&sd_data_index<48)root_cluster[(sd_data_index-44)*8+:8]<=sd_data;
                            if(sd_data_index>=510)signature[(sd_data_index-510)*8+:8]<=sd_data;
                            for(k=0;k<4;k=k+1)begin
                                if(sd_data_index==450+16*k)mbr_type[k]<=sd_data;
                                if(sd_data_index>=454+16*k&&sd_data_index<458+16*k)mbr_start[k][(sd_data_index-454-16*k)*8+:8]<=sd_data;
                                if(sd_data_index>=458+16*k&&sd_data_index<462+16*k)mbr_size[k][(sd_data_index-458-16*k)*8+:8]<=sd_data;
                            end
                        end
                        DIR:begin
                            entry[sd_data_index[4:0]*8+:8]<=sd_data;
                            if(sd_data_index[4:0]==31 && !dir_end && !found)begin
                                if(entry_complete[7:0]==0)dir_end<=1;
                                else if(entry_complete[87:0]==88'h4b41502020204f49445541 &&
                                    (entry_complete[95:88]&8'h18)==0 && entry_complete[95:88]!=8'h0f)begin
                                    found<=1;found_cluster<={entry_complete[175:160],entry_complete[223:208]};found_size<=entry_complete[255:224];
                                end
                            end
                        end
                        FAT:if(sd_data_index>=fat_offset && sd_data_index<fat_offset+4)fat_value[(sd_data_index-fat_offset)*8+:8]<=sd_data;
                        FILEDATA:begin file_data_valid<=1;file_data_index<=sd_data_index;file_data<=sd_data;end
                    endcase
                end
                case(state)
                    WAIT_CARD:if(card_ready)read_sector(0,BOOT,AFTER0);
                    REQUEST:if(sd_ready)begin sd_req<=1;state<=IO;end
                    IO:if(sd_done)state<=after_state;
                    CALC_A:begin
                        raw_boot_ok<=signature==16'haa55 && bps==512 && spc!=0 && (spc&(spc-1'b1))==0 &&
                            spc<=128 && reserved!=0 && (fat_count==1||fat_count==2) && root_entries==0 &&
                            total16==0 && fat16==0 && fat_size!=0 && fsver==0 &&
                            root_cluster>=2 && !root_cluster[31:28] && (!extflags[7]||extflags[3:0]<fat_count);
                        computed_shift<=decoded_shift;
                        fat_span_wide<=fat_count==2?{31'd0,fat_size,1'b0}:{32'd0,fat_size};
                        active_fat_wide<=extflags[7]&&extflags[3:0]!=0?{32'd0,fat_size}:64'd0;
                        fat_capacity_wide<={25'd0,fat_size,7'd0};
                        volume_end_wide<={32'd0,partition}+total_sectors;
                        state<=CALC_B;
                    end
                    CALC_B:begin
                        data_offset_wide<={32'd0,reserved}+fat_span_wide;
                        fat_relative_wide<={32'd0,reserved}+active_fat_wide;
                        state<=CALC_C;
                    end
                    CALC_C:begin
                        cluster_count_wide<=({32'd0,total_sectors}-data_offset_wide)>>computed_shift;
                        data_base_wide<={32'd0,partition}+data_offset_wide;
                        fat_base_wide<={32'd0,partition}+fat_relative_wide;
                        state<=CALC_D;
                    end
                    CALC_D:begin
                        boot_qualified<=raw_boot_ok && data_offset_wide<total_sectors &&
                            cluster_count_wide>=65525 && cluster_count_wide<28'hffffff5 &&
                            fat_capacity_wide>=cluster_count_wide+2 && root_cluster<cluster_count_wide+2 &&
                            volume_end_wide<=64'h100000000 && (partition==0||total_sectors<=partition_size) &&
                            fat_base_wide<64'h100000000 && data_base_wide<64'h100000000;
                        state<=boot_continuation;
                    end
                    AFTER0:if(boot_qualified)state<=AFTERBOOT;
                        else if(signature!=16'haa55)fail(3);
                        else begin
                            if((mbr_type[0]==8'h0b||mbr_type[0]==8'h0c)&&mbr_start[0]!=0&&mbr_size[0]!=0)begin partition<=mbr_start[0];partition_size<=mbr_size[0];read_sector(mbr_start[0],BOOT,AFTERBOOT);end
                            else if((mbr_type[1]==8'h0b||mbr_type[1]==8'h0c)&&mbr_start[1]!=0&&mbr_size[1]!=0)begin partition<=mbr_start[1];partition_size<=mbr_size[1];read_sector(mbr_start[1],BOOT,AFTERBOOT);end
                            else if((mbr_type[2]==8'h0b||mbr_type[2]==8'h0c)&&mbr_start[2]!=0&&mbr_size[2]!=0)begin partition<=mbr_start[2];partition_size<=mbr_size[2];read_sector(mbr_start[2],BOOT,AFTERBOOT);end
                            else if((mbr_type[3]==8'h0b||mbr_type[3]==8'h0c)&&mbr_start[3]!=0&&mbr_size[3]!=0)begin partition<=mbr_start[3];partition_size<=mbr_size[3];read_sector(mbr_start[3],BOOT,AFTERBOOT);end
                            else fail(4);
                        end
                    AFTERBOOT:if(!boot_qualified)fail(5);else begin
                        volume_clusters<=cluster_count_wide[31:0];fat_base<=fat_base_wide[31:0];data_base<=data_base_wide[31:0];spc_shift<=computed_shift;
                        root_current<=root_cluster;root_offset<=0;root_hops<=0;verify_cluster<=root_cluster;verify_hops<=0;state<=VERIFYROOT;
                    end
                    VERIFYROOT:read_fat(verify_cluster,AFTERVERIFYROOT);
                    AFTERVERIFYROOT:if(fat_value[27:0]>=28'hffffff8)state<=ROOT;
                        else if(!fat_next_ok||verify_hops>=MAX_CHAIN_HOPS-1)fail(8);
                        else begin verify_cluster<={4'd0,fat_value[27:0]};verify_hops<=verify_hops+1'b1;state<=VERIFYROOT;end
                    ROOT:read_sector(data_base+((root_current-2)<<spc_shift)+root_offset,DIR,AFTERROOT);
                    AFTERROOT:if(found)begin
                        if(found_cluster<2||found_cluster>=volume_clusters+2||found_size<512||found_size>33554432)fail(6);
                        else begin
                            file_first<=found_cluster;cache_cluster<=found_cluster;cache_index<=0;file_size<=found_size;verify_cluster<=found_cluster;
                            verify_left<=(((found_size+511)>>9)+spc-1'b1)>>spc_shift;verify_hops<=0;state<=VERIFYFILE;
                        end
                    end else if(dir_end)fail(7);
                    else if(root_offset+1<spc)begin root_offset<=root_offset+1'b1;state<=ROOT;end
                    else if(root_hops>=MAX_CHAIN_HOPS-1)fail(8);else read_fat(root_current,AFTERFATROOT);
                    AFTERFATROOT:if(!fat_next_ok||fat_value[27:0]==root_current)fail(8);
                        else begin root_current<={4'd0,fat_value[27:0]};root_offset<=0;root_hops<=root_hops+1'b1;state<=ROOT;end
                    VERIFYFILE:read_fat(verify_cluster,AFTERVERIFYFILE);
                    AFTERVERIFYFILE:if(verify_left==1)begin
                        if(fat_value[27:0]>=28'hffffff8)begin mounted<=1;state<=IDLE;end else fail(10);
                    end else if(!fat_next_ok||verify_hops>=MAX_CHAIN_HOPS-1)fail(10);
                    else begin verify_cluster<={4'd0,fat_value[27:0]};verify_left<=verify_left-1'b1;verify_hops<=verify_hops+1'b1;state<=VERIFYFILE;end
                    IDLE:if(file_req)begin
                        if(file_sector>=((file_size+511)>>9))fail(9);
                        else begin
                            target_sector<=file_sector;target_cluster<=file_sector>>spc_shift;hops<=0;
                            if((file_sector>>spc_shift)<cache_index)begin cache_cluster<=file_first;cache_index<=0;end
                            state<=MAPFILE;
                        end
                    end
                    MAPFILE:if(cache_index==target_cluster)read_sector(data_base+((cache_cluster-2)<<spc_shift)+(target_sector&(spc-1'b1)),FILEDATA,AFTERFILE);
                    else if(hops>=MAX_CHAIN_HOPS-1)fail(10);else read_fat(cache_cluster,AFTERFATFILE);
                    AFTERFATFILE:if(!fat_next_ok||fat_value[27:0]==cache_cluster)fail(10);
                        else begin cache_cluster<={4'd0,fat_value[27:0]};cache_index<=cache_index+1'b1;hops<=hops+1'b1;state<=MAPFILE;end
                    AFTERFILE:begin file_done<=1;state<=IDLE;end
                    default:begin end
                endcase
            end
        end
endmodule
