`timescale 1ns/1ps
// Task-local PCM source. All ports use the HDMI pixel clock domain.
module hdmi_pcm_source #(
    parameter integer CLK_HZ = 75000000,
    parameter integer SAMPLE_HZ = 48000
) (
    input wire clk,
    input wire rst_n,
    input wire mode_set,
    input wire [1:0] mode,
    input wire cancel,
    input wire pcm_start,
    input wire pcm_valid,
    input wire [15:0] pcm_data,
    input wire pcm_last,
    output wire pcm_ready,
    output wire pcm_busy,
    output reg pcm_done,
    output reg underrun,
    output reg underrun_pulse,
    output reg [1:0] active_mode,
    output reg audio_valid,
    output reg [23:0] audio_left,
    output wire [23:0] audio_right
);
    localparam integer PHASE_BITS = $clog2(CLK_HZ + SAMPLE_HZ);
    reg [PHASE_BITS-1:0] sample_phase;
    wire sample_due = sample_phase >= CLK_HZ - SAMPLE_HZ;
    reg [5:0] tone_phase;
    reg stream_active, playing, end_received;
    reg [1:0] count;
    reg [15:0] data0, data1;
    reg last0, last1;
    wire push = pcm_valid && pcm_ready;
    wire pop = sample_due && active_mode == 2 && stream_active && playing && count != 0;

    assign audio_right = audio_left;
    assign pcm_busy = active_mode == 2 && stream_active;
    assign pcm_ready = rst_n && active_mode == 2 && stream_active &&
        !end_received && count < 2 && !cancel && !mode_set && !pcm_start;

    function [15:0] sine_sample;
        input [5:0] phase;
        begin
            case (phase)
                 0: sine_sample = 16'sd0;
                 1: sine_sample = 16'sd535;
                 2: sine_sample = 16'sd1060;
                 3: sine_sample = 16'sd1567;
                 4: sine_sample = 16'sd2048;
                 5: sine_sample = 16'sd2493;
                 6: sine_sample = 16'sd2896;
                 7: sine_sample = 16'sd3250;
                 8: sine_sample = 16'sd3547;
                 9: sine_sample = 16'sd3784;
                10: sine_sample = 16'sd3956;
                11: sine_sample = 16'sd4061;
                12: sine_sample = 16'sd4096;
                13: sine_sample = 16'sd4061;
                14: sine_sample = 16'sd3956;
                15: sine_sample = 16'sd3784;
                16: sine_sample = 16'sd3547;
                17: sine_sample = 16'sd3250;
                18: sine_sample = 16'sd2896;
                19: sine_sample = 16'sd2493;
                20: sine_sample = 16'sd2048;
                21: sine_sample = 16'sd1567;
                22: sine_sample = 16'sd1060;
                23: sine_sample = 16'sd535;
                24: sine_sample = 16'sd0;
                25: sine_sample = -16'sd535;
                26: sine_sample = -16'sd1060;
                27: sine_sample = -16'sd1567;
                28: sine_sample = -16'sd2048;
                29: sine_sample = -16'sd2493;
                30: sine_sample = -16'sd2896;
                31: sine_sample = -16'sd3250;
                32: sine_sample = -16'sd3547;
                33: sine_sample = -16'sd3784;
                34: sine_sample = -16'sd3956;
                35: sine_sample = -16'sd4061;
                36: sine_sample = -16'sd4096;
                37: sine_sample = -16'sd4061;
                38: sine_sample = -16'sd3956;
                39: sine_sample = -16'sd3784;
                40: sine_sample = -16'sd3547;
                41: sine_sample = -16'sd3250;
                42: sine_sample = -16'sd2896;
                43: sine_sample = -16'sd2493;
                44: sine_sample = -16'sd2048;
                45: sine_sample = -16'sd1567;
                46: sine_sample = -16'sd1060;
                47: sine_sample = -16'sd535;
                default: sine_sample = 16'sd0;
            endcase
        end
    endfunction

    // Keep the sample schedule running through silence, commands and starvation.
    always @(posedge clk or negedge rst_n)
        if (!rst_n)
            sample_phase <= 0;
        else if (sample_due)
            sample_phase <= sample_phase + SAMPLE_HZ - CLK_HZ;
        else
            sample_phase <= sample_phase + SAMPLE_HZ;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tone_phase <= 0;
            active_mode <= 0;
            stream_active <= 0;
            playing <= 0;
            end_received <= 0;
            count <= 0;
            data0 <= 0;
            data1 <= 0;
            last0 <= 0;
            last1 <= 0;
            pcm_done <= 0;
            underrun <= 0;
            underrun_pulse <= 0;
            audio_valid <= 0;
            audio_left <= 0;
        end else begin
            audio_valid <= sample_due;
            audio_left <= 0;
            pcm_done <= 0;
            underrun_pulse <= 0;
            if (cancel || mode_set) begin
                active_mode <= cancel ? 0 : (mode == 3 ? 0 : mode);
                tone_phase <= 0;
                stream_active <= 0;
                playing <= 0;
                end_received <= 0;
                count <= 0;
                data0 <= 0;
                data1 <= 0;
                last0 <= 0;
                last1 <= 0;
            end else if (pcm_start && active_mode == 2) begin
                stream_active <= 1;
                playing <= 0;
                end_received <= 0;
                count <= 0;
                data0 <= 0;
                data1 <= 0;
                last0 <= 0;
                last1 <= 0;
            end else begin
                if (active_mode == 1 && sample_due) begin
                    audio_left <= {sine_sample(tone_phase), 8'd0};
                    tone_phase <= tone_phase == 47 ? 0 : tone_phase + 1'b1;
                end
                if (active_mode == 2 && stream_active) begin
                    // Prime two samples, or a complete one-sample clip.
                    if (!playing && (count == 2 || (count != 0 && end_received)))
                        playing <= 1;
                    if (push && pcm_last)
                        end_received <= 1;
                    case ({push, pop})
                        2'b10: begin
                            if (count == 0) begin data0 <= pcm_data; last0 <= pcm_last; end
                            else begin data1 <= pcm_data; last1 <= pcm_last; end
                            count <= count + 1'b1;
                        end
                        2'b01: begin
                            data0 <= data1;
                            last0 <= last1;
                            count <= count - 1'b1;
                        end
                        2'b11: begin
                            // ready is false when full, so this is count==1.
                            data0 <= pcm_data;
                            last0 <= pcm_last;
                        end
                        default: begin end
                    endcase
                    if (sample_due && playing) begin
                        if (count == 0) begin
                            underrun <= 1;
                            underrun_pulse <= 1;
                            stream_active <= 0;
                            playing <= 0;
                            count <= 0;
                        end else begin
                            audio_left <= {data0, 8'd0};
                            if (last0) begin
                                pcm_done <= 1;
                                stream_active <= 0;
                                playing <= 0;
                                count <= 0;
                            end
                        end
                    end
                end
            end
        end
    end
    // synthesis translate_off
    initial begin
        if (SAMPLE_HZ != 48000 || CLK_HZ <= SAMPLE_HZ)
            $fatal(1, "HDMI PCM requires 48kHz and a faster pixel clock");
    end
    // synthesis translate_on
endmodule
