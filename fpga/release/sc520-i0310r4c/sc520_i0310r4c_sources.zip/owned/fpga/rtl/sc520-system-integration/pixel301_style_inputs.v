// Synchronize the two style switches and qualify the entire word.
// The compositor commits this request exactly once, on its original input FS.
// D106 fixes production reset to SW0/A4. The style word uses board nets SW2:SW1.
module pixel301_style_inputs #(parameter integer STABLE_CYCLES=1500000)(
    input wire clk,rst_n,input wire [1:0] switches_async,
    output wire [1:0] style_request
);
    localparam integer W=STABLE_CYCLES<2?1:$clog2(STABLE_CYCLES+1);
    (* async_reg="true",keep="true",preserve="true" *) reg [1:0] meta,sync;
    reg [1:0] candidate,qualified;
    reg [W-1:0] count;
    assign style_request=qualified;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin meta<=0;sync<=0;candidate<=0;qualified<=0;count<=0;end
        else begin
            meta<=switches_async;sync<=meta;
            if(sync!=candidate)begin candidate<=sync;count<=0;end
            else if(count<STABLE_CYCLES)begin
                count<=count+1'b1;
                if(count==STABLE_CYCLES-1)qualified<=candidate;
            end
        end
endmodule
