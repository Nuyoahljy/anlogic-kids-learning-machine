// A022 leaf transport reused with the system's existing keys and video chain.
module pixel302_tf_audio #(parameter integer SD_POWER_CYCLES=750000)(
    input wire clk,rst_n,recover,event_valid,cancel,
    input wire [2:0] event_kind,input wire [3:0] event_item,input wire sd_miso,
    output wire sd_cs_n,sd_sck,sd_mosi,
    output wire audio_idle,audio_fault,audio_valid,
    output wire [23:0] audio_left,audio_right,
    output wire card_initialized,file_mounted,player_ready,playing
);
    wire sd_req,sd_ready,sd_done,sd_valid,sd_fault;
    wire [31:0] sd_lba,file_sector,file_size;
    wire [8:0] sd_index,file_index;
    wire [7:0] sd_byte,file_byte;
    wire file_req,file_ready,file_done,file_valid,file_fault;
    tf21_sdhc_ro #(.POWER_CYCLES(SD_POWER_CYCLES)) u_sd(.clk(clk),.rst_n(rst_n),.recover(recover),.read_valid(sd_req),.read_lba(sd_lba),
        .read_ready(sd_ready),.initialized(card_initialized),.fault(sd_fault),.error_code(),
        .data_valid(sd_valid),.data_index(sd_index),.data_byte(sd_byte),.read_done(sd_done),
        .sd_cs_n(sd_cs_n),.sd_sck(sd_sck),.sd_mosi(sd_mosi),.sd_miso(sd_miso));
    tf21_fat32_file u_file(.clk(clk),.rst_n(rst_n),.recover(recover),
        .card_ready(card_initialized),.card_fault(sd_fault),.sd_req(sd_req),.sd_lba(sd_lba),
        .sd_ready(sd_ready),.sd_done(sd_done),.sd_data_valid(sd_valid),.sd_data_index(sd_index),.sd_data(sd_byte),
        .file_req(file_req),.file_sector(file_sector),.file_ready(file_ready),
        .mounted(file_mounted),.fault(file_fault),.error_code(),.file_size(file_size),
        .file_data_valid(file_valid),.file_data_index(file_index),.file_data(file_byte),.file_done(file_done));
    wire pcm_set,pcm_start,pcm_cancel,pcm_valid,pcm_last,pcm_ready,pcm_done,pcm_underrun;
    wire [15:0] pcm_data;
    wire player_fault,play,stop_stream,invalid_event;
    wire [4:0] clip;
    wire transport_fault=sd_fault||file_fault||player_fault||pcm_underrun;
    pixel301_audio_events events(.clk(clk),.rst_n(rst_n),.recover(recover),.cancel(cancel),
        .event_valid(event_valid),.event_kind(event_kind),.event_item(event_item),
        .player_ready(player_ready),.player_busy(playing),.player_fault(transport_fault),
        .play(play),.player_cancel(stop_stream),.clip_index(clip),.audio_idle(audio_idle),
        .audio_fault(audio_fault),.invalid_event(invalid_event));
    tf302_pak_player u_player(.clk(clk),.rst_n(rst_n),.recover(recover),
        .mounted(file_mounted),.file_fault(file_fault),.file_size(file_size),
        .file_req(file_req),.file_sector(file_sector),.file_ready(file_ready),.file_done(file_done),
        .file_data_valid(file_valid),.file_data_index(file_index),.file_data(file_byte),
        .play(play),.cancel(stop_stream),.clip_index(clip),
        .ready(player_ready),.busy(playing),.fault(player_fault),.error_code(),
        .pcm_mode_set(pcm_set),.pcm_start(pcm_start),.pcm_cancel(pcm_cancel),
        .pcm_valid(pcm_valid),.pcm_data(pcm_data),.pcm_last(pcm_last),
        .pcm_ready(pcm_ready),.pcm_done(pcm_done),.pcm_underrun(pcm_underrun));
    hdmi_pcm_source u_pcm(.clk(clk),.rst_n(rst_n&&!recover),
        .mode_set(pcm_set),.mode(2'd2),.cancel(pcm_cancel||stop_stream),
        .pcm_start(pcm_start),.pcm_valid(pcm_valid),.pcm_data(pcm_data),.pcm_last(pcm_last),
        .pcm_ready(pcm_ready),.pcm_busy(),.pcm_done(pcm_done),.underrun(pcm_underrun),
        .underrun_pulse(),.active_mode(),.audio_valid(audio_valid),.audio_left(audio_left),.audio_right(audio_right));
endmodule
