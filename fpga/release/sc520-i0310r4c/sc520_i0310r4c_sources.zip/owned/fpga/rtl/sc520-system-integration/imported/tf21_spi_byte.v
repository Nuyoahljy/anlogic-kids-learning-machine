`timescale 1ns/1ps
module tf21_spi_byte (
    input wire clk, rst_n, start,
    input wire [7:0] tx,
    input wire [7:0] half_period,
    input wire miso,
    output reg sck, mosi, busy, done,
    output reg [7:0] rx
);
    reg [7:0] divider, shift_tx, shift_rx;
    reg [2:0] bit_index;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin
            sck<=0;mosi<=1;busy<=0;done<=0;rx<=0;
            divider<=0;shift_tx<=0;shift_rx<=0;bit_index<=0;
        end else begin
            done<=0;
            if(!busy)begin
                sck<=0;
                if(start)begin
                    busy<=1;divider<=half_period-1'b1;bit_index<=7;
                    shift_tx<=tx;shift_rx<=0;mosi<=tx[7];
                end
            end else if(divider!=0)divider<=divider-1'b1;
            else begin
                divider<=half_period-1'b1;
                if(!sck)begin sck<=1;shift_rx<={shift_rx[6:0],miso};end
                else begin
                    sck<=0;
                    if(bit_index==0)begin busy<=0;done<=1;rx<=shift_rx;mosi<=1;end
                    else begin bit_index<=bit_index-1'b1;shift_tx<={shift_tx[6:0],1'b1};mosi<=shift_tx[6];end
                end
            end
        end
endmodule
