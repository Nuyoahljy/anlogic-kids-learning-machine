// Local pre-OSD candidate. All inputs, including mode_request, share clk.
// Three register layers: sampled at edge N, output after edge N+2.
// rst_n may assert asynchronously; the integrator must synchronize release.
module sc520_cartoon_style (
    input wire clk,
    input wire rst_n,
    input wire in_frame_start,
    input wire in_de,
    input wire in_hsync,
    input wire in_vsync,
    input wire [1:0] mode_request,
    input wire [10:0] in_x,
    input wire [9:0] in_y,
    input wire [23:0] in_rgb,
    output reg out_frame_start,
    output reg out_de,
    output reg out_hsync,
    output reg out_vsync,
    output reg [1:0] out_mode,
    output reg [10:0] out_x,
    output reg [9:0] out_y,
    output reg [23:0] out_rgb
);
    reg [1:0] frame_mode;
    wire [1:0] safe_request = mode_request == 2'd1 ? 2'd1 :
                             mode_request == 2'd2 ? 2'd2 : 2'd0;
    wire [1:0] pixel_mode = in_frame_start ? safe_request : frame_mode;

    reg prev_valid;
    reg [10:0] prev_x;
    reg [9:0] prev_y;
    reg [23:0] prev_rgb;
    wire neighbor = prev_valid && in_de && !in_frame_start &&
                    in_x != 11'd0 && in_x == prev_x + 11'd1 &&
                    in_y == prev_y;

    function [7:0] abs_difference;
        input [7:0] left;
        input [7:0] right;
        begin
            abs_difference = left >= right ? left - right : right - left;
        end
    endfunction

    function [7:0] local_blend;
        input [7:0] current;
        input [7:0] previous;
        reg [9:0] sum;
        begin
            sum = {2'd0, current} + {1'd0, current, 1'b0} +
                  {2'd0, previous} + 10'd2;
            local_blend = sum[9:2];
        end
    endfunction

    function [7:0] clamp_channel;
        input [7:0] channel;
        input signed [9:0] delta;
        reg signed [9:0] sum;
        begin
            sum = $signed({2'b00, channel}) + delta;
            if (sum < 10'sd0)
                clamp_channel = 8'd0;
            else if (sum > 10'sd255)
                clamp_channel = 8'd255;
            else
                clamp_channel = sum[7:0];
        end
    endfunction

    // Darken a detected transition without replacing its hue with black.
    function [7:0] ink_channel;
        input [7:0] channel;
        reg [10:0] sum;
        begin
            sum = {1'd0, channel, 2'b00} + {3'd0, channel} + 11'd4;
            ink_channel = sum[10:3];
        end
    endfunction

    wire [7:0] dr = abs_difference(in_rgb[23:16], prev_rgb[23:16]);
    wire [7:0] dg = abs_difference(in_rgb[15:8], prev_rgb[15:8]);
    wire [7:0] db = abs_difference(in_rgb[7:0], prev_rgb[7:0]);
    wire smooth_neighbor = neighbor && dr <= 8'd12 &&
                           dg <= 8'd12 && db <= 8'd12;
    wire edge_pixel = neighbor && (dr >= 8'd48 || dg >= 8'd48 ||
                                  db >= 8'd48);
    wire [23:0] filtered_rgb = smooth_neighbor ?
        {local_blend(in_rgb[23:16], prev_rgb[23:16]),
         local_blend(in_rgb[15:8], prev_rgb[15:8]),
         local_blend(in_rgb[7:0], prev_rgb[7:0])} : in_rgb;
    wire [9:0] gray_sum = {2'd0, in_rgb[23:16]} +
                         {1'd0, in_rgb[15:8], 1'b0} +
                         {2'd0, in_rgb[7:0]} + 10'd2;

    reg a_fs, a_de, a_hs, a_vs, a_edge;
    reg [1:0] a_mode;
    reg [10:0] a_x;
    reg [9:0] a_y;
    reg [23:0] a_rgb, a_filtered;
    reg [7:0] a_gray;
    wire [9:0] luminance_sum = {2'd0, a_filtered[23:16]} +
                              {1'd0, a_filtered[15:8], 1'b0} +
                              {2'd0, a_filtered[7:0]} + 10'd2;
    wire [7:0] luminance = luminance_sum[9:2];
    wire [8:0] rounded_luminance = {1'b0, luminance} + 9'd16;
    wire [7:0] band_luminance = rounded_luminance[8] ? 8'd255 :
                              {rounded_luminance[7:5], 5'b00000};
    wire signed [9:0] band_difference =
        $signed({2'b00, band_luminance}) - $signed({2'b00, luminance});

    reg b_fs, b_de, b_hs, b_vs, b_edge;
    reg [1:0] b_mode;
    reg [10:0] b_x;
    reg [9:0] b_y;
    reg [23:0] b_rgb, b_filtered;
    reg [7:0] b_gray;
    reg signed [9:0] b_delta;
    wire [23:0] toned_rgb =
        {clamp_channel(b_filtered[23:16], b_delta),
         clamp_channel(b_filtered[15:8], b_delta),
         clamp_channel(b_filtered[7:0], b_delta)};
    wire [23:0] cartoon_rgb = b_edge ?
        {ink_channel(toned_rgb[23:16]),
         ink_channel(toned_rgb[15:8]),
         ink_channel(toned_rgb[7:0])} : toned_rgb;
    wire [23:0] selected_rgb = b_mode == 2'd1 ?
        {b_gray, b_gray, b_gray} : b_mode == 2'd2 ? cartoon_rgb : b_rgb;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_mode <= 2'd0;
            prev_valid <= 1'b0;
            prev_x <= 11'd0;
            prev_y <= 10'd0;
            prev_rgb <= 24'd0;
            a_fs <= 1'b0;
            a_de <= 1'b0;
            a_hs <= 1'b0;
            a_vs <= 1'b0;
            a_edge <= 1'b0;
            a_mode <= 2'd0;
            a_x <= 11'd0;
            a_y <= 10'd0;
            a_rgb <= 24'd0;
            a_filtered <= 24'd0;
            a_gray <= 8'd0;
            b_fs <= 1'b0;
            b_de <= 1'b0;
            b_hs <= 1'b0;
            b_vs <= 1'b0;
            b_edge <= 1'b0;
            b_mode <= 2'd0;
            b_x <= 11'd0;
            b_y <= 10'd0;
            b_rgb <= 24'd0;
            b_filtered <= 24'd0;
            b_gray <= 8'd0;
            b_delta <= 10'sd0;
            out_frame_start <= 1'b0;
            out_de <= 1'b0;
            out_hsync <= 1'b0;
            out_vsync <= 1'b0;
            out_mode <= 2'd0;
            out_x <= 11'd0;
            out_y <= 10'd0;
            out_rgb <= 24'd0;
        end else begin
            if (in_frame_start)
                frame_mode <= safe_request;
            prev_valid <= in_de;
            prev_x <= in_x;
            prev_y <= in_y;
            prev_rgb <= in_rgb;
            a_fs <= in_frame_start;
            a_de <= in_de;
            a_hs <= in_hsync;
            a_vs <= in_vsync;
            a_edge <= edge_pixel;
            a_mode <= pixel_mode;
            a_x <= in_x;
            a_y <= in_y;
            a_rgb <= in_rgb;
            a_filtered <= filtered_rgb;
            a_gray <= gray_sum[9:2];
            b_fs <= a_fs;
            b_de <= a_de;
            b_hs <= a_hs;
            b_vs <= a_vs;
            b_edge <= a_edge;
            b_mode <= a_mode;
            b_x <= a_x;
            b_y <= a_y;
            b_rgb <= a_rgb;
            b_filtered <= a_filtered;
            b_gray <= a_gray;
            b_delta <= band_difference >>> 1;
            out_frame_start <= b_fs;
            out_de <= b_de;
            out_hsync <= b_hs;
            out_vsync <= b_vs;
            out_mode <= b_mode;
            out_x <= b_x;
            out_y <= b_y;
            out_rgb <= b_de ? selected_rgb : 24'd0;
        end
    end
endmodule
