`timescale 1ns/1ps
// Two 512-byte banks: total 10.667ms, one-bank refill budget 5.333ms at 48k.
module tf21_pak_player #(
    parameter integer START_TIMEOUT_CYCLES=1500000000
) (
    input wire clk,rst_n,recover,mounted,file_fault,
    input wire [31:0] file_size,
    output reg file_req,
    output reg [31:0] file_sector,
    input wire file_ready,file_done,file_data_valid,
    input wire [8:0] file_data_index,
    input wire [7:0] file_data,
    input wire play,cancel,
    input wire [4:0] clip_index,
    output wire ready,
    output reg busy,fault,
    output reg [3:0] error_code,
    output reg pcm_mode_set,pcm_start,pcm_cancel,
    output wire pcm_valid,
    output wire [15:0] pcm_data,
    output wire pcm_last,
    input wire pcm_ready,pcm_done,pcm_underrun
);
    localparam WAIT_MOUNT=0,HREQ=1,HREAD=2,HCHECK=3,IDLE=4,LOAD=5,READ=6,
        DRAIN=7,FAILED=8;
    reg [3:0] state;
    reg [63:0] magic;
    reg [31:0] header[0:5];
    reg [31:0] ids[0:31],starts[0:31],lengths[0:31];
    reg [5:0] check_index;
    reg header_ok;
    reg [31:0] next_sector,read_left,total_samples,sent_samples,age;
    reg [8:0] read_samples,bank_samples[0:1];
    reg [1:0] bank_ready;
    reg write_bank,play_bank,started;
    reg [7:0] low_byte,play_offset;
    reg [15:0] buffer_mem[0:511];
    reg [15:0] memory_q,held_sample;
    reg sample_pending,held_valid;
    wire [8:0] read_address={play_bank,play_offset};
    wire can_load=started && !held_valid && !sample_pending && bank_ready[play_bank];
    wire consume=pcm_valid && pcm_ready;
    integer j;
    function [31:0] logical_id;
        input [5:0] index;
        begin
            if(index<14)logical_id=index+1;
            else if(index<28)logical_id=index+87;
            else case(index)28:logical_id=201;29:logical_id=202;30:logical_id=206;default:logical_id=207;endcase
        end
    endfunction
    assign ready=header_ok && state==IDLE && !fault;
    assign pcm_valid=held_valid && busy && !cancel && !recover && !fault;
    assign pcm_data=held_sample;
    assign pcm_last=sent_samples+1==total_samples;
    wire [63:0] entry_end=({32'd0,starts[check_index]}<<9)+({32'd0,lengths[check_index]}<<1);
    // Synchronous RAM read; no reset/clear of the memory array.
    always @(posedge clk)begin
        if(can_load)memory_q<=buffer_mem[read_address];
        if(state==READ && file_data_valid && file_data_index[0] &&
            (file_data_index>>1)<read_samples && !cancel)
            buffer_mem[{write_bank,file_data_index[8:1]}]<={file_data,low_byte};
    end
    task fail;
        input [3:0] code;
        begin fault<=1;error_code<=code;state<=FAILED;busy<=0;held_valid<=0;bank_ready<=0;pcm_cancel<=1;end
    endtask
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin
            state<=WAIT_MOUNT;magic<=0;file_req<=0;file_sector<=0;check_index<=0;header_ok<=0;
            busy<=0;fault<=0;error_code<=0;pcm_mode_set<=0;pcm_start<=0;pcm_cancel<=0;
            next_sector<=0;read_left<=0;total_samples<=0;sent_samples<=0;age<=0;
            read_samples<=0;bank_samples[0]<=0;bank_samples[1]<=0;bank_ready<=0;
            write_bank<=0;play_bank<=0;started<=0;low_byte<=0;play_offset<=0;
            held_sample<=0;sample_pending<=0;held_valid<=0;
            for(j=0;j<6;j=j+1)header[j]<=0;
            for(j=0;j<32;j=j+1)begin ids[j]<=0;starts[j]<=0;lengths[j]<=0;end
        end else if(recover)begin
            state<=WAIT_MOUNT;file_req<=0;header_ok<=0;busy<=0;fault<=0;error_code<=0;
            pcm_mode_set<=0;pcm_start<=0;pcm_cancel<=1;started<=0;bank_ready<=0;held_valid<=0;sample_pending<=0;age<=0;
        end else begin
            file_req<=0;pcm_mode_set<=0;pcm_start<=0;pcm_cancel<=0;
            if(file_fault)fail(1);
            else if(busy && pcm_underrun)fail(2);
            else if(busy && !started && age==START_TIMEOUT_CYCLES-1)fail(3);
            else if(cancel && busy)begin
                busy<=0;started<=0;bank_ready<=0;held_valid<=0;sample_pending<=0;
                pcm_cancel<=1;
                // There is at most one file transaction. Drain it before idle;
                // never attach its delayed bytes/end to a new clip.
                if(state==READ && !file_done)state<=DRAIN;else state<=IDLE;
            end else begin
                if(busy&&!started)age<=age+1'b1;
                if(state==READ && file_data_valid && !file_data_index[0])low_byte<=file_data;
                if(can_load)sample_pending<=1;
                else if(sample_pending)begin held_sample<=memory_q;held_valid<=1;sample_pending<=0;end
                if(consume)begin
                    held_valid<=0;sent_samples<=sent_samples+1'b1;
                    if({1'b0,play_offset}+1==bank_samples[play_bank])begin
                        bank_ready[play_bank]<=0;play_bank<=!play_bank;play_offset<=0;
                    end else play_offset<=play_offset+1'b1;
                end
                if(busy && !started && (bank_ready==2'b11 || (read_left==0 && bank_ready!=0)))begin
                    pcm_start<=1;started<=1;
                end
                if(busy && started && pcm_done)begin busy<=0;started<=0;held_valid<=0;sample_pending<=0;state<=IDLE;end
                else case(state)
                    WAIT_MOUNT:if(mounted)begin
                        magic<=0;for(j=0;j<6;j=j+1)header[j]<=0;state<=HREQ;
                    end
                    HREQ:if(file_ready)begin file_req<=1;file_sector<=0;state<=HREAD;end
                    HREAD:begin
                        if(file_data_valid)begin
                            if(file_data_index<8)magic[file_data_index*8+:8]<=file_data;
                            else if(file_data_index<32)header[(file_data_index-8)>>2][file_data_index[1:0]*8+:8]<=file_data;
                            else if(file_data_index<416)begin
                                case((file_data_index-32)%12)
                                    0,1,2,3:ids[(file_data_index-32)/12][file_data_index[1:0]*8+:8]<=file_data;
                                    4,5,6,7:starts[(file_data_index-32)/12][file_data_index[1:0]*8+:8]<=file_data;
                                    default:lengths[(file_data_index-32)/12][file_data_index[1:0]*8+:8]<=file_data;
                                endcase
                            end
                        end
                        if(file_done)begin
                            if(magic!=64'h31304d435044494b || header[0]!=1 || header[1]!=48000 ||
                                header[2]!=32 || header[3]!=12 || header[4]!=1 || header[5]!=16)fail(4);
                            else begin check_index<=0;state<=HCHECK;end
                        end
                    end
                    HCHECK:if(ids[check_index]!=logical_id(check_index)||starts[check_index]==0||
                        lengths[check_index]==0||lengths[check_index]>1920000||entry_end>file_size)fail(5);
                    else if((check_index==0 && starts[0]!=1) ||
                        (check_index!=31 && ((entry_end+511)>>9)!=starts[check_index+1]) ||
                        (check_index==31 && (((entry_end+511)>>9)<<9)!=file_size))fail(6);
                    else if(check_index==31)begin header_ok<=1;state<=IDLE;end
                    else check_index<=check_index+1'b1;
                    IDLE:if(play && header_ok)begin
                        busy<=1;pcm_mode_set<=1;next_sector<=starts[clip_index];read_left<=lengths[clip_index];
                        total_samples<=lengths[clip_index];sent_samples<=0;age<=0;
                        bank_ready<=0;write_bank<=0;play_bank<=0;play_offset<=0;
                        started<=0;held_valid<=0;sample_pending<=0;state<=LOAD;
                    end
                    LOAD:if(read_left!=0 && !bank_ready[write_bank] && file_ready)begin
                        file_req<=1;file_sector<=next_sector;read_samples<=read_left>256?256:read_left[8:0];state<=READ;
                    end
                    READ:if(file_done)begin
                        bank_ready[write_bank]<=1;bank_samples[write_bank]<=read_samples;
                        write_bank<=!write_bank;next_sector<=next_sector+1'b1;read_left<=read_left-read_samples;state<=LOAD;
                    end
                    DRAIN:if(file_done)state<=IDLE;
                    default:begin end
                endcase
            end
        end
endmodule
