// D0281 private interpretation of the existing 800-bit diagnostic mailbox.
module pixel282_grid_osd #(parameter [15:0] VERSION=16'h0282)(
    input wire clk,rst_n,frame_start,
    input wire [10:0] pixel_x,input wire [9:0] pixel_y,
    input wire [799:0] packet,input wire fresh,input wire [7:0] age_ms,
    input wire [255:0] diagnostic,input wire [31:0] i2c_diagnostic,input wire [7:0] business_flags,
    output reg active,output reg [23:0] rgb
);
    reg [799:0] snapshot;
    reg [255:0] capture_snapshot;
    reg [31:0] i2c_snapshot;
    reg [7:0] business;
    reg snapshot_fresh,invalidated;
    wire trusted=snapshot[780] && snapshot_fresh && !invalidated && fresh;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin snapshot<=0;capture_snapshot<=0;i2c_snapshot<=0;business<=0;snapshot_fresh<=0;invalidated<=0;end
        else if(frame_start)begin
            snapshot<=packet;capture_snapshot<=diagnostic;i2c_snapshot<=i2c_diagnostic;business<=business_flags;
            snapshot_fresh<=fresh;invalidated<=0;
        end
        else if(!fresh)invalidated<=1;
    wire region_next=pixel_x>=168 && pixel_x<1064 && pixel_y>=512 && pixel_y<608;
    wire [10:0] dx=pixel_x-168;
    reg [2:0] row_next;
    reg [3:0] dy_next;
    always @* begin
        if(pixel_y<524)begin row_next=0;dy_next=pixel_y-512;end
        else if(pixel_y<536)begin row_next=1;dy_next=pixel_y-524;end
        else if(pixel_y<548)begin row_next=2;dy_next=pixel_y-536;end
        else if(pixel_y<560)begin row_next=3;dy_next=pixel_y-548;end
        else if(pixel_y<572)begin row_next=4;dy_next=pixel_y-560;end
        else if(pixel_y<584)begin row_next=5;dy_next=pixel_y-572;end
        else if(pixel_y<596)begin row_next=6;dy_next=pixel_y-584;end
        else begin row_next=7;dy_next=pixel_y-596;end
    end
    wire [8:0] marker_next;
    genvar n;
    generate for(n=0;n<9;n=n+1)begin: grid_marks
        localparam integer CX=n%3==0 ? 128:n%3==1 ? 640:1152;
        localparam integer CY=n/3==0 ? 128:n/3==1 ? 384:640;
        assign marker_next[n]=(CY<512) && pixel_x>=CX-5 && pixel_x<=CX+5 &&
            pixel_y>=CY-5 && pixel_y<=CY+5 &&
            (pixel_x==CX-5 || pixel_x==CX+5 || pixel_y==CY-5 || pixel_y==CY+5);
    end endgenerate
    reg region;
    reg [8:0] marker;
    reg [2:0] row;
    reg [6:0] column;
    reg [2:0] dot_x;
    reg [3:0] dy;
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin region<=0;marker<=0;row<=0;column<=0;dot_x<=0;dy<=0;end
        else begin
            region<=region_next;marker<=marker_next;row<=row_next;
            column<=dx[9:3];dot_x<=dx[2:0];dy<=dy_next;
        end
    function [7:0] digit;
        input [31:0] value;
        input integer index;
        reg [3:0] nibble;
        begin nibble=value>>(index*4);digit=nibble<10 ? "0"+nibble:"A"+nibble-10;end
    endfunction
    reg [7:0] character;
    integer entry,offset,index;
    reg [23:0] value;
    reg [6:0] raw_high,wb_high;
    always @* begin
        character=" ";entry=0;offset=0;index=0;value=0;raw_high=0;wb_high=0;
        if(row==0)begin
            case(column)
                0:character="D";
                6:character="F";
                16:character="V";
                17:character=trusted ? "1":"0";
                19:character="X";
                20:character=digit({24'd0,snapshot[779:772]},1);
                21:character=digit({24'd0,snapshot[779:772]},0);
                23:character="R";
                28:character="B";
                33:character="E";
                34:character="0";35:character="4";36:character="B";37:character="0";
                39:character="A";
                40:character="0";41:character="0";42:character="9";43:character="0";
                45:character="M";
                46:character=digit({23'd0,snapshot[616:608]},2);
                47:character=digit({23'd0,snapshot[616:608]},1);
                48:character=digit({23'd0,snapshot[616:608]},0);
                50:character="E";
                56:character="Q";
                66:character="B";
                70:character="C";
                77:character="R";
                84:character="I";
                91:character="H";
                97:character="L";
                103:character="Y";
                109:character="S";
                110:character=digit({26'd0,snapshot[622:617]},1);
                111:character=digit({26'd0,snapshot[622:617]},0);
                default:begin
                    if(column>=1 && column<=4)character=digit({16'd0,VERSION},4-column);
                    else if(column>=7 && column<=14)character=digit(snapshot[31:0],14-column);
                    else if(column>=24 && column<=26)character=digit({23'd0,snapshot[598:590]},26-column);
                    else if(column>=29 && column<=31)character=digit({23'd0,snapshot[607:599]},31-column);
                    else if(column>=51 && column<=54)character=digit({16'd0,capture_snapshot[239:224]},54-column);
                    else if(column>=57 && column<=64)character=digit(i2c_snapshot,64-column);
                    else if(column>=67 && column<=68)character=digit({24'd0,business},68-column);
                    else if(column>=71 && column<=75)character=digit(capture_snapshot[191:160],75-column);
                    else if(column>=78 && column<=82)character=digit(capture_snapshot[159:128],82-column);
                    else if(column>=85 && column<=89)character=digit(capture_snapshot[127:96],89-column);
                    else if(column>=92 && column<=95)character=digit({16'd0,capture_snapshot[223:208]},95-column);
                    else if(column>=98 && column<=101)character=digit({16'd0,capture_snapshot[95:80]},101-column);
                    else if(column>=104 && column<=107)character=digit({16'd0,capture_snapshot[79:64]},107-column);
                end
            endcase
        end else if(row<=6)begin
            if(column==0)character=row[0] ? "R":"W";
            if(column==1)character=row[0] ? "A":"B";
            if(column==2 && row[0])character="W";
            for(entry=0;entry<3;entry=entry+1)begin
                if(column>=6+entry*24 && column<15+entry*24)begin
                    offset=column-(6+entry*24);
                    index=((row-1)/2)*3+entry;
                    value=row[0] ? snapshot[32+index*24+:24]:snapshot[248+index*24+:24];
                    if(offset==0)character="P";
                    else if(offset==1)character=digit(index,0);
                    else if(offset==2)character=":";
                    else character=digit({8'd0,value},8-offset);
                end
            end
        end else begin
            if(column==0)character="H";
            if(column==1)character="C";
            for(entry=0;entry<9;entry=entry+1)begin
                if(column>=6+entry*10 && column<13+entry*10)begin
                    offset=column-(6+entry*10);
                    raw_high=snapshot[464+entry*7+:7];
                    wb_high=snapshot[527+entry*7+:7];
                    case(offset)
                        0:character=digit(entry,0);
                        1:character=":";
                        2:character=digit({25'd0,raw_high},1);
                        3:character=digit({25'd0,raw_high},0);
                        4:character="/";
                        5:character=digit({25'd0,wb_high},1);
                        6:character=digit({25'd0,wb_high},0);
                    endcase
                end
            end
        end
    end
    function [4:0] glyph;
        input [7:0] ch;
        input [2:0] row;
        reg [34:0] bitmap;
        begin
            case(ch)
                "0":bitmap=35'b01110_10001_10011_10101_11001_10001_01110;
                "1":bitmap=35'b00100_01100_00100_00100_00100_00100_01110;
                "2":bitmap=35'b01110_10001_00001_00010_00100_01000_11111;
                "3":bitmap=35'b11110_00001_00001_01110_00001_00001_11110;
                "4":bitmap=35'b00010_00110_01010_10010_11111_00010_00010;
                "5":bitmap=35'b11111_10000_10000_11110_00001_00001_11110;
                "6":bitmap=35'b01110_10000_10000_11110_10001_10001_01110;
                "7":bitmap=35'b11111_00001_00010_00100_01000_01000_01000;
                "8":bitmap=35'b01110_10001_10001_01110_10001_10001_01110;
                "9":bitmap=35'b01110_10001_10001_01111_00001_00001_01110;
                "A":bitmap=35'b01110_10001_10001_11111_10001_10001_10001;
                "B":bitmap=35'b11110_10001_10001_11110_10001_10001_11110;
                "C":bitmap=35'b01111_10000_10000_10000_10000_10000_01111;
                "D":bitmap=35'b11110_10001_10001_10001_10001_10001_11110;
                "E":bitmap=35'b11111_10000_10000_11110_10000_10000_11111;
                "F":bitmap=35'b11111_10000_10000_11110_10000_10000_10000;
                "G":bitmap=35'b01111_10000_10000_10111_10001_10001_01111;
                "H":bitmap=35'b10001_10001_10001_11111_10001_10001_10001;
                "I":bitmap=35'b01110_00100_00100_00100_00100_00100_01110;
                "L":bitmap=35'b10000_10000_10000_10000_10000_10000_11111;
                "N":bitmap=35'b10001_11001_11001_10101_10011_10011_10001;
                "Q":bitmap=35'b01110_10001_10001_10001_10101_10010_01101;
                "R":bitmap=35'b11110_10001_10001_11110_10100_10010_10001;
                "Y":bitmap=35'b10001_10001_01010_00100_00100_00100_00100;
                "M":bitmap=35'b10001_11011_10101_10101_10001_10001_10001;
                "P":bitmap=35'b11110_10001_10001_11110_10000_10000_10000;
                "S":bitmap=35'b01111_10000_10000_01110_00001_00001_11110;
                "T":bitmap=35'b11111_00100_00100_00100_00100_00100_00100;
                "U":bitmap=35'b10001_10001_10001_10001_10001_10001_01110;
                "V":bitmap=35'b10001_10001_10001_10001_10001_01010_00100;
                "W":bitmap=35'b10001_10001_10001_10101_10101_11011_10001;
                "X":bitmap=35'b10001_10001_01010_00100_01010_10001_10001;
                "O":bitmap=35'b01110_10001_10001_10001_10001_10001_01110;
                ":":bitmap=35'b00000_00100_00100_00000_00100_00100_00000;
                "/":bitmap=35'b00001_00001_00010_00100_01000_10000_10000;
                ",":bitmap=35'b00000_00000_00000_00000_00100_00100_01000;
                "=":bitmap=35'b00000_11111_00000_11111_00000_00000_00000;
                default:bitmap=0;
            endcase
            case(row)
                0:glyph=bitmap[34:30];1:glyph=bitmap[29:25];2:glyph=bitmap[24:20];
                3:glyph=bitmap[19:15];4:glyph=bitmap[14:10];5:glyph=bitmap[9:5];
                6:glyph=bitmap[4:0];default:glyph=0;
            endcase
        end
    endfunction
    wire [4:0] dots=glyph(character,dy[2:0]);
    wire lit=dot_x<5 && dy<7 && dots[4-dot_x];
    always @(posedge clk or negedge rst_n)
        if(!rst_n)begin active<=0;rgb<=0;end
        else begin
            active<=region || |marker;
            rgb<=region ? (lit ? (trusted ? 24'hffff80:24'hff9c9c):24'h101820):
                |marker ? 24'h00ffff:24'd0;
        end
endmodule
