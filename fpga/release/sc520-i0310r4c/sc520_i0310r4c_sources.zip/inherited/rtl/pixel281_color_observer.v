// Capture-side real tap/metadata binding and compact diagnostic packet.
module pixel281_color_observer #(
    parameter integer FRAME_WIDTH=1280,FRAME_HEIGHT=720,
    parameter integer CLASS_X=160,CLASS_Y=120,CLASS_W=960,CLASS_H=480,
    parameter integer CENTER_X=636,CENTER_Y=356,PAPER_X=192,PAPER_Y=144,
    parameter integer GRID_X0=96,GRID_X1=640,GRID_X2=1184,
    parameter integer GRID_Y0=144,GRID_Y1=360,GRID_Y2=496
) (
    input wire clk,rst_n,diagnostics_rst_n,join_rst_n,flush,
    input wire frame_start,
    input wire [31:0] frame_id,
    input wire valid,eol,
    input wire [95:0] pre_wb,post_wb,post_tone,
    input wire [31:0] pixel_id,
    input wire [8:0] gain_r,gain_b,
    input wire stats_event,stats_good,
    input wire [31:0] stats_id,
    input wire [20:0] neutral_count,
    input wire frame_done,frame_good,
    input wire [31:0] done_id,
    input wire analysis_event,analysis_good,
    input wire [31:0] analysis_id,
    input wire [148:0] analysis_data,
    output wire out_event,
    output wire [799:0] out_packet
);
    localparam integer CB=$clog2(FRAME_WIDTH*FRAME_HEIGHT+1);
    reg have_stats;
    reg [31:0] final_stats_id;
    reg [20:0] final_neutral;
    reg epoch_bad;
    wire pixel_mismatch=valid && pixel_id!=frame_id;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin have_stats<=0;final_stats_id<=0;final_neutral<=0;epoch_bad<=0;end
        else if(flush)begin have_stats<=0;epoch_bad<=0;end
        else begin
            if(frame_start)begin have_stats<=0;epoch_bad<=0;end
            if(pixel_mismatch)epoch_bad<=1;
            if(stats_event)begin
                if(have_stats || !stats_good)epoch_bad<=1;
                have_stats<=stats_good;final_stats_id<=stats_id;final_neutral<=neutral_count;
            end
            if(frame_done)have_stats<=0;
        end
    end
    wire diag_event,diag_good,diag_reject;
    wire [31:0] diag_id;
    wire [8:0] diag_gr,diag_gb,window_valid;
    wire [215:0] raw_means,wb_means;
    wire [62:0] raw_high,wb_high;
    pixel281_grid_diagnostics #(.FRAME_WIDTH(FRAME_WIDTH),.FRAME_HEIGHT(FRAME_HEIGHT),
        .X0(GRID_X0),.X1(GRID_X1),.X2(GRID_X2),.Y0(GRID_Y0),.Y1(GRID_Y1),.Y2(GRID_Y2)) diagnostics (
        .clk(clk),.rst_n(diagnostics_rst_n),.flush(flush),.in_sof(frame_start),.in_frame_id(frame_id),
        .in_valid(valid),.in_eol(eol),.in_pre_wb(pre_wb),.in_post_wb(post_wb),
        .in_gain_r(gain_r),.in_gain_b(gain_b),.in_frame_done(frame_done),
        .in_frame_good(frame_good && have_stats && final_stats_id==done_id && !epoch_bad && !pixel_mismatch),
        .in_done_id(done_id),.out_valid(diag_event),.out_trusted(diag_good),
        .out_reject(diag_reject),.out_reject_reason(),.out_frame_id(diag_id),
        .out_gain_r(diag_gr),.out_gain_b(diag_gb),.out_raw_means(raw_means),.out_wb_means(wb_means),
        .out_raw_high(raw_high),.out_wb_high(wb_high),.out_window_valid(window_valid));
    wire [622:0] color_record;
    assign color_record[31:0]=diag_reject ? frame_id:diag_id;
    assign color_record[247:32]=raw_means;
    assign color_record[463:248]=wb_means;
    assign color_record[526:464]=raw_high;
    assign color_record[589:527]=wb_high;
    assign color_record[598:590]=diag_gr;
    assign color_record[607:599]=diag_gb;
    assign color_record[616:608]=window_valid;
    assign color_record[622:617]=6'd0;
    pixel14_observation_join joiner (
        .clk(clk),.rst_n(join_rst_n),.flush(flush),.color_event(diag_event || diag_reject),.color_good(diag_event && diag_good),
        .color_data(color_record),.analysis_event(analysis_event),.analysis_good(analysis_good),
        .analysis_id(analysis_id),.analysis_data(analysis_data),.out_event(out_event),.out_packet(out_packet));
endmodule
