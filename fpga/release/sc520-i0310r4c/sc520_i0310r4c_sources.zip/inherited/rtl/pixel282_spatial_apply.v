// Bilinear Q8 attenuation field. Three video registers; ten pixel DSPs.
module pixel282_spatial_apply #(
    parameter integer FRAME_WIDTH=1280,FRAME_HEIGHT=720,
    parameter integer X_START=128,X_SHIFT=9,Y_START=128,Y_SHIFT=8
)(
    input wire clk,rst_n,frame_sof,
    input wire [242:0] coefficients,
    input wire in_valid,in_eol,
    input wire [95:0] in_rgb,
    output wire busy,
    output reg out_valid,out_eol,
    output reg [95:0] out_rgb
);
    localparam integer GROUPS=FRAME_WIDTH/4,XS=1<<X_SHIFT,YS=1<<Y_SHIFT;
    reg [12:0] group_x,line_y;
    wire line_end=in_valid && group_x==GROUPS-1;
    reg row_bank;
    reg [8:0] rows0[0:8],rows1[0:8];
    reg [1:0] row_ready;
    reg [1:0] row_state;
    reg calc_bank,initial_second;
    reg [12:0] calc_y;
    reg [3:0] calc_index;
    reg signed [18:0] row_product;
    reg [8:0] row_base;
    reg [4:0] table_row;
    reg [Y_SHIFT:0] weight_y;
    reg [8:0] upper_gain,lower_gain;
    wire [8:0] control_top[0:8],control_middle[0:8],control_bottom[0:8];
    genvar a;
    generate for(a=0;a<9;a=a+1)begin: fixed_coefficient_words
        assign control_top[a]=coefficients[a*9+:9];
        assign control_middle[a]=coefficients[(a+9)*9+:9];
        assign control_bottom[a]=coefficients[(a+18)*9+:9];
    end endgenerate
    always @*begin
        table_row=0;weight_y=0;
        if(calc_y<=Y_START)begin table_row=0;weight_y=0;end
        else if(calc_y>=Y_START+2*YS)begin table_row=9;weight_y=YS;end
        else if(calc_y<Y_START+YS)begin table_row=0;weight_y=calc_y-Y_START;end
        else begin table_row=9;weight_y=calc_y-Y_START-YS;end
        upper_gain=table_row==0 ? control_top[calc_index]:control_middle[calc_index];
        lower_gain=table_row==0 ? control_middle[calc_index]:control_bottom[calc_index];
    end
    wire signed [9:0] row_delta=$signed({1'b0,lower_gain})-$signed({1'b0,upper_gain});
    wire signed [19:0] interpolated=$signed({1'b0,row_base})+((row_product+(1<<(Y_SHIFT-1)))>>>Y_SHIFT);
    integer q;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            group_x<=0;line_y<=0;row_bank<=0;row_ready<=0;row_state<=0;
            calc_bank<=0;initial_second<=0;calc_y<=0;calc_index<=0;row_product<=0;row_base<=256;
            for(q=0;q<9;q=q+1)begin rows0[q]<=256;rows1[q]<=256;end
        end else if(frame_sof)begin
            group_x<=0;line_y<=0;row_bank<=0;row_ready<=0;
            row_state<=1;calc_bank<=0;calc_y<=0;calc_index<=0;initial_second<=1;
        end else begin
            if(in_valid)begin
                if(line_end)begin
                    group_x<=0;line_y<=line_y+1'b1;row_bank<=!row_bank;
                    calc_bank<=row_bank;row_ready[row_bank]<=0;
                    calc_y<=line_y+13'd2;calc_index<=0;row_state<=1;initial_second<=0;
                end else group_x<=group_x+1'b1;
            end
            if(row_state==1)begin
                row_base<=upper_gain;
                row_product<=row_delta*$signed({1'b0,weight_y});
                row_state<=2;
            end else if(row_state==2)begin
                if(calc_bank)rows1[calc_index]<=interpolated[8:0];
                else rows0[calc_index]<=interpolated[8:0];
                if(calc_index==8)begin
                    row_ready[calc_bank]<=1;
                    if(initial_second)begin
                        calc_bank<=1;calc_y<=1;calc_index<=0;row_state<=1;initial_second<=0;
                    end else row_state<=0;
                end else begin calc_index<=calc_index+1'b1;row_state<=1;end
            end
        end
    end
    wire [14:0] pixel_x={group_x,2'b0};
    wire ready=row_ready[row_bank];
    wire [8:0] row_gain[0:8];
    genvar g;
    generate for(g=0;g<9;g=g+1)begin: active_row
        assign row_gain[g]=!ready ? 9'd256:row_bank ? rows1[g]:rows0[g];
    end endgenerate
    reg signed [19:0] accumulator[0:2];
    reg signed [10:0] slope[0:2];
    reg signed [19:0] base[0:2];
    integer channel;
    always @*begin
        for(channel=0;channel<3;channel=channel+1)begin
            slope[channel]=0;base[channel]=$signed({1'b0,row_gain[channel]})<<<X_SHIFT;
            if(pixel_x<X_START)begin
                slope[channel]=0;
            end else if(pixel_x<X_START+XS)begin
                slope[channel]=$signed({1'b0,row_gain[3+channel]})-$signed({1'b0,row_gain[channel]});
                base[channel]=pixel_x==X_START ? ($signed({1'b0,row_gain[channel]})<<<X_SHIFT):accumulator[channel];
            end else if(pixel_x<X_START+2*XS)begin
                slope[channel]=$signed({1'b0,row_gain[6+channel]})-$signed({1'b0,row_gain[3+channel]});
                base[channel]=pixel_x==X_START+XS ? ($signed({1'b0,row_gain[3+channel]})<<<X_SHIFT):accumulator[channel];
            end else begin
                base[channel]=$signed({1'b0,row_gain[6+channel]})<<<X_SHIFT;
            end
        end
    end
    function [16:0] logic_product;
        input [7:0] value;
        input [8:0] gain;
        reg [16:0] p0,p1,p2,p3,p4,p5,p6,p7,p8;
        begin
            p0=gain[0] ? {9'd0,value}:0;p1=gain[1] ? {8'd0,value,1'b0}:0;
            p2=gain[2] ? {7'd0,value,2'b0}:0;p3=gain[3] ? {6'd0,value,3'b0}:0;
            p4=gain[4] ? {5'd0,value,4'b0}:0;p5=gain[5] ? {4'd0,value,5'b0}:0;
            p6=gain[6] ? {3'd0,value,6'b0}:0;p7=gain[7] ? {2'd0,value,7'b0}:0;
            p8=gain[8] ? {1'd0,value,8'b0}:0;
            logic_product=((p0+p1)+(p2+p3))+((p4+p5)+(p6+p7))+p8;
        end
    endfunction
    reg [95:0] samples;
    reg [8:0] gains[0:11];
    reg [16:0] products[0:11];
    reg gain_valid,gain_eol,product_valid,product_eol;
    assign busy=gain_valid || product_valid || out_valid;
    reg signed [19:0] gain_position;
    reg [8:0] gain;
    integer lane,c,i;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            samples<=0;gain_valid<=0;gain_eol<=0;product_valid<=0;product_eol<=0;out_valid<=0;out_eol<=0;out_rgb<=0;
            for(i=0;i<3;i=i+1)accumulator[i]<=0;
            for(i=0;i<12;i=i+1)begin products[i]<=0;gains[i]<=256;end
        end else if(frame_sof)begin
            gain_valid<=0;gain_eol<=0;product_valid<=0;product_eol<=0;out_valid<=0;out_eol<=0;out_rgb<=0;
            for(i=0;i<3;i=i+1)accumulator[i]<=0;
        end else begin
            gain_valid<=in_valid;gain_eol<=in_eol && in_valid;
            product_valid<=gain_valid;product_eol<=gain_eol;
            out_valid<=product_valid;out_eol<=product_eol;
            if(in_valid)begin
                samples<=in_rgb;
                for(i=0;i<3;i=i+1)accumulator[i]<=base[i]+(slope[i]<<<2);
                for(lane=0;lane<4;lane=lane+1)for(c=0;c<3;c=c+1)begin
                    case(lane)
                        0:gain_position=base[c]+(slope[c]<<<1)+slope[c]+(1<<(X_SHIFT-1));
                        1:gain_position=base[c]+(slope[c]<<<1)+(1<<(X_SHIFT-1));
                        2:gain_position=base[c]+slope[c]+(1<<(X_SHIFT-1));
                        3:gain_position=base[c]+(1<<(X_SHIFT-1));
                    endcase
                    gain=gain_position>>>X_SHIFT;
                    gains[lane*3+c]<=gain;
                end
            end
            if(gain_valid)for(lane=0;lane<4;lane=lane+1)begin
                products[lane*3]<=samples[lane*24+16+:8]*gains[lane*3];
                if(lane<2)products[lane*3+1]<=samples[lane*24+8+:8]*gains[lane*3+1];
                else products[lane*3+1]<=logic_product(samples[lane*24+8+:8],gains[lane*3+1]);
                products[lane*3+2]<=samples[lane*24+:8]*gains[lane*3+2];
            end
            for(i=0;i<12;i=i+1)
                out_rgb[(i/3)*24+(2-i%3)*8+:8]<=product_valid ? ((products[i]+17'd128)>>8):8'd0;
        end
    end
    // synthesis translate_off
    initial if(FRAME_WIDTH%4!=0 || GROUPS<64 || X_START%4!=0 ||
               X_START<4 || X_START+2*XS+4>FRAME_WIDTH ||
               Y_START<4 || Y_START+2*YS+4>FRAME_HEIGHT ||
               X_SHIFT<4 || X_SHIFT>9 || Y_SHIFT<4 || Y_SHIFT>8)
        $fatal(1,"pixel282_spatial_apply unsupported geometry");
    always @(posedge clk)if(rst_n && in_valid && !frame_sof)begin
        if(!ready)$fatal(1,"spatial row coefficients not ready");
        if(line_end && row_state!=0)$fatal(1,"spatial row engine overrun");
    end
    // synthesis translate_on
endmodule
