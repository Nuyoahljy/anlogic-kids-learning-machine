// Nine simultaneous 8x8 windows, before/after WB. No pixel-path registers.
module pixel281_grid_diagnostics #(
    parameter integer FRAME_WIDTH=1280, FRAME_HEIGHT=720,
    parameter integer X0=96, X1=640, X2=1184,
    parameter integer Y0=144, Y1=360, Y2=496
) (
    input wire clk,rst_n,flush,
    input wire in_valid,in_sof,in_eol,
    input wire [31:0] in_frame_id,
    input wire [95:0] in_pre_wb,in_post_wb,
    input wire [8:0] in_gain_r,in_gain_b,
    input wire in_frame_done,in_frame_good,
    input wire [31:0] in_done_id,
    output reg out_valid,out_trusted,out_reject,
    output reg [7:0] out_reject_reason,
    output reg [31:0] out_frame_id,
    output reg [8:0] out_gain_r,out_gain_b,
    output reg [215:0] out_raw_means,out_wb_means,
    output reg [62:0] out_raw_high,out_wb_high,
    output reg [8:0] out_window_valid
);
    localparam integer GROUPS=FRAME_WIDTH/4, TOTAL=GROUPS*FRAME_HEIGHT;
    localparam integer GROUP_BITS=$clog2(TOTAL+1);
    reg active;
    reg [1:0] pending;
    reg [31:0] active_id;
    reg [GROUP_BITS-1:0] groups_seen;
    reg [12:0] group_x,raster_y,lines_seen;
    reg [8:0] frame_gain_r,frame_gain_b;
    wire start_ok=in_sof && !active && pending==0 && !in_frame_done;
    wire stream_active=active || start_ok;
    wire [12:0] current_group=start_ok ? 13'd0:group_x;
    wire [12:0] current_y=start_ok ? 13'd0:raster_y;
    wire [GROUP_BITS-1:0] prior_groups=start_ok ? {GROUP_BITS{1'b0}}:groups_seen;
    wire overlap=(in_sof && !start_ok) ||
        (pending!=0 && (in_valid || in_sof || in_eol || in_frame_done));
    wire orphan=in_valid && !stream_active;
    wire marker=in_eol && !in_valid;
    wire raster=in_valid && stream_active &&
        (prior_groups>=TOTAL || current_y>=FRAME_HEIGHT ||
         in_eol!=(current_group==GROUPS-1));
    wire identity=(in_valid && active && in_frame_id!=active_id) ||
        (in_frame_done && active && in_done_id!=active_id);
    wire bad_done=in_frame_done && (!active || pending!=0 || in_valid ||
        in_sof || in_eol || !in_frame_good || groups_seen!=TOTAL ||
        lines_seen!=FRAME_HEIGHT);
    wire changed_gain=in_valid && active && groups_seen!=0 &&
        (in_gain_r!=frame_gain_r || in_gain_b!=frame_gain_b);
    wire [7:0] fault={1'b0,changed_gain,bad_done,identity,raster,marker,orphan,overlap};
    wire accept_pixel=in_valid && stream_active && fault==0 && !flush;

    function [23:0] pixel;
        input [95:0] value;
        input integer lane;
        begin pixel=value[(3-lane)*24+:24];end
    endfunction
    function high;
        input [23:0] value;
        begin high=value[23:16]>=247 || value[15:8]>=247 || value[7:0]>=247;end
    endfunction
    wire [8:0] hit;
    genvar q;
    generate for(q=0;q<9;q=q+1)begin: windows
        localparam integer CX=q%3==0 ? X0:q%3==1 ? X1:X2;
        localparam integer CY=q/3==0 ? Y0:q/3==1 ? Y1:Y2;
        assign hit[q]=current_group>=(CX-4)/4 && current_group<(CX+4)/4 &&
            current_y>=CY-4 && current_y<CY+4;
    end endgenerate

    reg s0_valid,s1_valid;
    reg [8:0] s0_hit,s1_hit;
    reg [8:0] raw_pair[0:5],wb_pair[0:5];
    reg [1:0] raw_high_pair[0:1],wb_high_pair[0:1];
    reg [9:0] raw_group[0:2],wb_group[0:2];
    reg [2:0] raw_high_group,wb_high_group;
    reg [13:0] raw_sum[0:26],wb_sum[0:26];
    reg [6:0] counts[0:8],raw_high_count[0:8],wb_high_count[0:8];
    wire coverage_ok;
    wire [8:0] covered;
    generate for(q=0;q<9;q=q+1)begin: coverage
        assign covered[q]=counts[q]==64;
    end endgenerate
    assign coverage_ok=&covered;
    integer i,j,c;
    reg [23:0] rp0,rp1,wp0,wp1;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            s0_valid<=0;s1_valid<=0;s0_hit<=0;s1_hit<=0;
            raw_high_group<=0;wb_high_group<=0;
            for(i=0;i<6;i=i+1)begin raw_pair[i]<=0;wb_pair[i]<=0;end
            for(i=0;i<2;i=i+1)begin raw_high_pair[i]<=0;wb_high_pair[i]<=0;end
            for(i=0;i<3;i=i+1)begin raw_group[i]<=0;wb_group[i]<=0;end
        end else if(flush || fault!=0)begin
            s0_valid<=0;s1_valid<=0;s0_hit<=0;s1_hit<=0;
        end else begin
            s0_valid<=accept_pixel;s0_hit<=accept_pixel ? hit:9'd0;
            s1_valid<=s0_valid;s1_hit<=s0_hit;
            if(accept_pixel)begin
                for(j=0;j<2;j=j+1)begin
                    rp0=pixel(in_pre_wb,2*j);rp1=pixel(in_pre_wb,2*j+1);
                    wp0=pixel(in_post_wb,2*j);wp1=pixel(in_post_wb,2*j+1);
                    for(c=0;c<3;c=c+1)begin
                        raw_pair[j*3+c]<={1'b0,rp0[(2-c)*8+:8]}+{1'b0,rp1[(2-c)*8+:8]};
                        wb_pair[j*3+c]<={1'b0,wp0[(2-c)*8+:8]}+{1'b0,wp1[(2-c)*8+:8]};
                    end
                    raw_high_pair[j]<={1'b0,high(rp0)}+{1'b0,high(rp1)};
                    wb_high_pair[j]<={1'b0,high(wp0)}+{1'b0,high(wp1)};
                end
            end
            if(s0_valid)begin
                for(c=0;c<3;c=c+1)begin
                    raw_group[c]<={1'b0,raw_pair[c]}+{1'b0,raw_pair[c+3]};
                    wb_group[c]<={1'b0,wb_pair[c]}+{1'b0,wb_pair[c+3]};
                end
                raw_high_group<={1'b0,raw_high_pair[0]}+{1'b0,raw_high_pair[1]};
                wb_high_group<={1'b0,wb_high_pair[0]}+{1'b0,wb_high_pair[1]};
            end
        end
    end

    integer w,k;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            active<=0;pending<=0;active_id<=0;groups_seen<=0;
            group_x<=0;raster_y<=0;lines_seen<=0;frame_gain_r<=0;frame_gain_b<=0;
            out_valid<=0;out_trusted<=0;out_reject<=0;out_reject_reason<=0;
            out_frame_id<=0;out_gain_r<=0;out_gain_b<=0;
            out_raw_means<=0;out_wb_means<=0;out_raw_high<=0;out_wb_high<=0;out_window_valid<=0;
            for(w=0;w<9;w=w+1)begin counts[w]<=0;raw_high_count[w]<=0;wb_high_count[w]<=0;end
            for(w=0;w<27;w=w+1)begin raw_sum[w]<=0;wb_sum[w]<=0;end
        end else begin
            out_valid<=0;out_reject<=0;
            if(flush || fault!=0)begin
                active<=0;pending<=0;groups_seen<=0;group_x<=0;raster_y<=0;lines_seen<=0;
                out_trusted<=0;out_window_valid<=0;
                if(!flush)begin out_reject<=1;out_reject_reason<=fault;end
            end else begin
                if(start_ok)begin
                    active<=1;active_id<=in_frame_id;groups_seen<=0;group_x<=0;raster_y<=0;lines_seen<=0;
                    out_trusted<=0;out_window_valid<=0;out_reject_reason<=0;
                    for(w=0;w<9;w=w+1)begin counts[w]<=0;raw_high_count[w]<=0;wb_high_count[w]<=0;end
                    for(w=0;w<27;w=w+1)begin raw_sum[w]<=0;wb_sum[w]<=0;end
                end
                if(accept_pixel)begin
                    groups_seen<=prior_groups+1'b1;
                    if(prior_groups==0)begin frame_gain_r<=in_gain_r;frame_gain_b<=in_gain_b;end
                    if(in_eol)begin group_x<=0;raster_y<=current_y+1'b1;lines_seen<=current_y+1'b1;end
                    else begin group_x<=current_group+1'b1;raster_y<=current_y;end
                end
                if(s1_valid)begin
                    for(w=0;w<9;w=w+1)if(s1_hit[w])begin
                        counts[w]<=counts[w]+7'd4;
                        raw_high_count[w]<=raw_high_count[w]+raw_high_group;
                        wb_high_count[w]<=wb_high_count[w]+wb_high_group;
                        for(k=0;k<3;k=k+1)begin
                            raw_sum[w*3+k]<=raw_sum[w*3+k]+raw_group[k];
                            wb_sum[w*3+k]<=wb_sum[w*3+k]+wb_group[k];
                        end
                    end
                end
                if(in_frame_done)begin active<=0;pending<=2;end
                else if(pending!=0)begin
                    pending<=pending-1'b1;
                    // Two blank cycles drain both contribution registers,
                    // including a final group immediately before done.
                    if(pending==1)begin
                        out_frame_id<=active_id;out_gain_r<=frame_gain_r;out_gain_b<=frame_gain_b;
                        if(coverage_ok)begin
                            out_valid<=1;out_trusted<=1;out_window_valid<=covered;out_reject_reason<=0;
                            for(w=0;w<9;w=w+1)begin
                                out_raw_high[w*7+:7]<=raw_high_count[w];
                                out_wb_high[w*7+:7]<=wb_high_count[w];
                                for(k=0;k<3;k=k+1)begin
                                    out_raw_means[w*24+(2-k)*8+:8]<=raw_sum[w*3+k][13:6];
                                    out_wb_means[w*24+(2-k)*8+:8]<=wb_sum[w*3+k][13:6];
                                end
                            end
                        end else begin out_reject<=1;out_trusted<=0;out_window_valid<=0;out_reject_reason<=8'h80;end
                    end
                end
            end
        end
    end
    // synthesis translate_off
    initial begin
        if(FRAME_WIDTH<24 || FRAME_WIDTH%4!=0 || FRAME_HEIGHT<24 ||
           X0<4 || X1<X0+8 || X2<X1+8 || X2+4>FRAME_WIDTH ||
           X0%4!=0 || X1%4!=0 || X2%4!=0 ||
           Y0<4 || Y1<Y0+8 || Y2<Y1+8 || Y2+4>FRAME_HEIGHT)
            $fatal(1,"pixel281_grid_diagnostics invalid geometry");
    end
    // synthesis translate_on
endmodule
