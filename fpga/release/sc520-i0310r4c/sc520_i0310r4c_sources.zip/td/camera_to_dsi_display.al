<Project Version="3" Minor="2" Path=".">
  <Project_Created_Time />
  <TD_Encoding>UTF-8</TD_Encoding>
  <TD_Version>6.2.168116</TD_Version>
  <Name>camera_to_dsi_display</Name>
  <HardWare>
    <Family>PH1</Family>
    <Device>PH1P35MDG324</Device>
    <Speed>-3</Speed>
  </HardWare>
  <Source_Files>
    <Verilog>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/custom_project/sc520-system-integration/overlay/design_top_wrapper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="1" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/video_in.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="5" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/video_out.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="7" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mc_to_user_interface.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="8" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/signal_delay.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="15" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/awb.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="18" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/ph1p35_ddr/ph1p35_324_ddr_wrapper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="20" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/csi_unpacket_2lane.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="21" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/custom_project/sc520-system-integration/overlay/isp_top.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="22" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/raw10_unpacket_2lane.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="23" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/uial2axis.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="24" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/bilinear_interpolation.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="25" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/demosaic.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="26" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/line_buffer_demosaic.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="27" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/mipi_to_raw_converter.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="28" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/raw_matrix_3x3_buffer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="29" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/zhenghe.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="30" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/data128_96/data128_96.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="31" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/data96_128/data96_128.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="34" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics500_cfg/SC500GainTbl.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="35" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics500_cfg/uicfgcs500.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="36" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics500_cfg/uics500regAE.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="37" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/custom_project/sc520-system-integration/overlay/uii2c.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="38" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uiisp_beta/ae_set.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="39" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/hdmi_tx.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="40" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/hdmi_1_4b_transmitter_core_wrapper.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="41" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/hdmi_phy_warpper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="42" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/lane_lvds_10_1.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="43" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/vtc/uivtc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="44" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/hdmi_mixer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="45" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/I2S_receiver.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="46" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/audio_arc_calculate.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="47" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/key_remove_shakes.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="48" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics520_cfg/SC520GainTbl.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="49" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/custom_project/sc520-system-integration/overlay/uicfgcs520.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="50" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics520_cfg/uics520reg_720p60.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="51" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics520_cfg/uics520regAE.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="52" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics520_cfg/uics520reg.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="54" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/uics520_cfg/uics520reg_full_2560x1920_30.v">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="55" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/quiz/quiz_millisecond_tick.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="131" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/quiz/quiz_key_inputs.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="134" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/block_frame_recognizer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="200" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-card-recognition/pixel14/capture_rgb96.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="201" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_block_filter.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="202" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_block_shape_guard.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="203" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_capture_provenance.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="204" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_card_matcher.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="205" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_card_template_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="206" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_diag_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="207" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="208" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-card-recognition/pixel14/pixel14_result_cdc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="209" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_rotation_matcher.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="210" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_scene_preprocess.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="211" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-card-recognition/items14/items14_content.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="212" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-card-recognition/items14/items14_font_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="213" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/items14_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="214" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/items14_question_bank.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="215" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/items14_quiz_control.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="216" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/items14_result_join.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="217" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/items14_system.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="218" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/card_template_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="219" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/card_result_filter.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="220" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/custom_project/sc520-system-integration/overlay/pixel14_color_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="221" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_color_diag_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="222" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_color_diagnostics.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="223" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_color_observer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="224" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_observation_bridge.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="225" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel14_observation_join.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="226" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/sc520_processing_display.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="227" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/sc520_color_classify.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="228" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-card-recognition/display17/sc520_logo_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="229" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel17_display_request.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="230" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel22_audio.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="231" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel22_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="232" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel22_content.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="233" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel22_font_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="234" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel22_panel.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="235" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/dfr0534_items14_audio.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="236" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/dfr0534_link.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="237" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/dfr0534_player.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="238" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/dfr0534_player_core.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="239" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/dfr0534_track_map.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="240" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/t020_audio_queue.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="241" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel23_color_diag_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="242" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel23_color_observer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="243" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel23_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="244" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel23_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="245" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_bg_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="246" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_block_core.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="247" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_block_recognizer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="248" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_block_recognizer_piped.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="249" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_classify_pipe.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="250" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-color-integration/pixel26_color_classify.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="251" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="252" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_fixed_exposure.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="253" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="254" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-color-integration/pixel26_processing_display.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="255" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-color-integration/pixel26_saturation.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="256" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel26_scene_preprocess.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="257" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel28_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="258" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel28_processing_display.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="259" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel28_saturation.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="260" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_bg_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="261" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_color_observer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="262" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="263" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_fixed_exposure.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="264" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_grid_diagnostics.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="265" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel281_grid_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="266" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_bg_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="267" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_color_observer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="268" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="269" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_grid_osd.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="270" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_spatial_apply.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="271" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel282_spatial_cal.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="272" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/inherited/rtl/pixel286_bg_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="273" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/pixel286_color_observer.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="274" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_scene_preprocess.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="424" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_shape_scores.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="425" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_rotation_matcher.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="426" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_arbitrate.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="427" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_result_filter.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="428" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_result_join.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="429" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_question_bank.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="430" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_quiz_control.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="431" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_system.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="432" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/items30_content.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="433" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_panel.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="434" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="435" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-shape-card30/pixel30_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="436" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/items301_content.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="437" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/items301_font_rom.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="438" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_audio_events.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="439" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration-i0309/pixel309_track_caption.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="440" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_compositor.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="441" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_panel.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="442" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_pipeline.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="443" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_style_inputs.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="444" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/pixel301_tf_audio.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="445" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/sc520_cartoon_style.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="446" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/tf301_pak_player.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="447" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/hdmi_pcm_source.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="448" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/tf21_fat32_file.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="449" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/tf21_pak_player.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="450" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/tf21_sdhc_ro.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="451" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration/imported/tf21_spi_byte.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="452" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/owned/fpga/rtl/sc520-system-integration-i0310/pixel310_awb_retrigger.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="453" />
        </FileInfo>
      </File>
    </Verilog>
    <System_Verilog>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/mipi_dphy_rx_ph1p_mipiio_wrapper.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="3" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/ph1p_mipiio_rx_wrapper.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="4" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/byte_aligner.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="10" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/byte_aligner_wrapper.enc.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="11" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/channel_aligner.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="12" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/channel_aligner_wrapper.enc.sv">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="13" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/mipi_dphy_rx/hs_detect.enc.v">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="14" />
        </FileInfo>
      </File>
    </System_Verilog>
    <ADC_FILE>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/constraints/pin.adc">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="constraint_1" />
          <Attr Name="CompileOrder" Val="1" />
        </FileInfo>
      </File>
    </ADC_FILE>
    <SDC_FILE>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/constraints/production.sdc">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="constraint_1" />
          <Attr Name="CompileOrder" Val="2" />
        </FileInfo>
      </File>
    </SDC_FILE>
    <IP_FILE>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/ip_source/PLL/PLL.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="2" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/ip_source/w128_d512_fifo/w128_d512_fifo.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="6" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/ip_source/w155_d512_fifo/w155_d512_fifo.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="9" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/ip_source/blk_mem_gen_awb_delay_signal/blk_mem_gen_awb_delay_signal.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="16" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/ip_source/divider/divider.ipc">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="17" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/ph1p35_ddr/ddr2/ddr2.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="19" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_zhenghe/blk_mem_gen_zhenghe.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="32" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/user_source/hdl_source/isp/demosaic_4x_2_0/blk_mem_gen_demosaic/blk_mem_gen_demosaic.xml">
        <FileInfo>
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="33" />
        </FileInfo>
      </File>
      <File Path="E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/j319/vendor/td_project/al_ip/ChipWatcher_mipi/ChipWatcher_mipi.xml">
        <FileInfo>
          <Attr Name="AutoExcluded" Val="true" />
          <Attr Name="UsedInSyn" Val="true" />
          <Attr Name="UsedInP&R" Val="true" />
          <Attr Name="BelongTo" Val="design_1" />
          <Attr Name="CompileOrder" Val="53" />
        </FileInfo>
      </File>
    </IP_FILE>
  </Source_Files>
  <FileSets>
    <FileSet Name="design_1" Type="DesignFiles">
        </FileSet>
    <FileSet Name="constraint_1" Type="ConstrainFiles">
        </FileSet>
  </FileSets>
  <TOP_MODULE>
    <LABEL>design_top_wrapper</LABEL>
    <MODULE>design_top_wrapper</MODULE>
    <CREATEINDEX>user</CREATEINDEX>
  </TOP_MODULE>
  <Property>
    </Property>
  <Device_Settings>
    </Device_Settings>
  <Configurations>
    <Control0>
      <mclk_freq>33MHz</mclk_freq>
    </Control0>
    <FeatureRow>
      <boot_mode>mspix4</boot_mode>
    </FeatureRow>
  </Configurations>
  <Runs>
    <Run Name="syn_1" Type="Synthesis" ConstraintSet="constraint_1" Description="" Active="true" useDefaultScript="false">
      <Strategy Name="Default_Synthesis_Strategy">
            </Strategy>
      <UserParams>
            </UserParams>
    </Run>
    <Run Name="phy_1" Type="PhysicalDesign" ConstraintSet="constraint_1" Description="" SynRun="syn_1" Active="true">
      <Strategy Name="Default_PhysicalDesign_Strategy">
        <BitgenProperty::GeneralOption>
          <compress>on</compress>
        </BitgenProperty::GeneralOption>
      </Strategy>
      <UserParams>
            </UserParams>
    </Run>
  </Runs>
  <Project_Settings>
    </Project_Settings>
</Project>