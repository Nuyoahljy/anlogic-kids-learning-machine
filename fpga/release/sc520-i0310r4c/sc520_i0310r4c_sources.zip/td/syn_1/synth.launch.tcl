proc i0310r4c_synthesis {} {
source settings.cfg
if {$device_name ne "ph1_35p.db" || $package_name ne "PH1P35MDG324" || $speed ne "3" || $run_type ne "syn" || $start_step ne "read_design" || $end_step ne "opt_gate"} {error "Wrong I0310R4C synthesis settings"}
foreach command {place route bitgen insert_debugger} {proc $command {args} {error "Outside I0310R4C synthesis"}}
source camera_to_dsi_display.tcl
write_verilog i0310r4c-synthesis-netlist.v
report_clock_summary -file i0310r4c-clocks.rpt
report_timing_summary -file i0310r4c-timing.rpt
report_timing_exception -file i0310r4c-exceptions.rpt
report_timing_ignored -file i0310r4c-ignored.rpt
}
if {[catch {i0310r4c_synthesis} reason]} {puts stderr $reason; exit 1}
puts "I0310R4C_SYNTHESIS_NATIVE_COMPLETE"
exit 0
