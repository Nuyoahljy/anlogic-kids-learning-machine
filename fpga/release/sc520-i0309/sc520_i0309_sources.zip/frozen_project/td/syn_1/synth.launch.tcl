proc i0309_synthesis {} {
source settings.cfg
if {$device_name ne "ph1_35p.db" || $package_name ne "PH1P35MDG324" || $speed ne "3" || $run_type ne "syn" || $start_step ne "read_design" || $end_step ne "opt_gate"} {error "Wrong I0309 synthesis settings"}
foreach command {place route bitgen insert_debugger} {proc $command {args} {error "Outside I0309 synthesis"}}
source camera_to_dsi_display.tcl
write_verilog i0309-synthesis-netlist.v
report_clock_summary -file i0309-clocks.rpt
report_timing_summary -file i0309-timing.rpt
report_timing_exception -file i0309-exceptions.rpt
report_timing_ignored -file i0309-ignored.rpt
}
if {[catch {i0309_synthesis} reason]} {puts stderr $reason; exit 1}
puts "I0309_SYNTHESIS_NATIVE_COMPLETE"
exit 0
