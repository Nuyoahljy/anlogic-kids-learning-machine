
"""I0309 r310/u312 fixed-input SDF bounded CDC audit.
Run with python -I -B; default is read-only. --write-report creates one new report.
No TD, simulator, bit generation, network or hardware operation is implemented.
All numeric delays are ps; SDF composite setup already includes endpoint slice logic.
"""
import sys,re,json,hashlib,collections,math
from datetime import datetime, timezone, timedelta
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8")
base=Path(r"E:/juan/FPGA/worktrees/anlogic-kids-learning-machine/sc520-system-integration/evidence/sc520-system-integration/u312/td/pl_1")
audit=Path(r"E:/juan/FPGA/learning/sc520-system-integration/physical-review/i0309-final")
norm=lambda x:re.sub(r"\s+","",x).lstrip("\\")
unesc=lambda x:re.sub(r"\\(.)",r"\1",x)
gate=json.loads((audit/"gate-inspection.json").read_text())
s=(base/"routed-netlist.v").read_text();s=re.sub(r"//[^\n]*","",s)
pat=re.compile(r"(?m)^  (PH1P_[A-Za-z0-9_]+)\s*(?:#\((.*?)\)\s*)?\s*(\\[^\s]+|[A-Za-z_]\w*)\s+\((.*?)\);",re.S)
cells={};outputs=collections.defaultdict(list)
for typ,params,name,porttext in pat.findall(s):
 ports={pn:norm(expr) for pn,expr in re.findall(r"\.(\w+)\((.*?)\)(?:,|\s*$)",porttext,re.S)}
 name=name.lstrip("\\"); cells[name]={"type":typ,"params":params,"ports":ports,"settings":dict(re.findall(r'\.(\w+)\(([^()]+)\)',params))}
 for port in ("oqa","oqb"):
  if port in ports:outputs[ports[port]].append((name,port))
pairs=[]
for group in ("ForwardRetainedPairs","GrayPairs"):
 for g in gate[group]:
  sn=g["SourceQ"];dn=g["DestinationQ"]
  if group=="GrayPairs":
   assert sn.endswith("_syn_3") and dn.endswith("_syn_3")
   sn=sn[:-6];dn=dn[:-6]
  assert len(outputs[sn])==1,(sn,outputs[sn])
  assert len(outputs[dn])==1,(dn,outputs[dn])
  sc,sp=outputs[sn][0];dc,dp=outputs[dn][0]
  ips=[pn for pn,net in cells[dc]["ports"].items() if net==sn and pn not in ("oqa","oqb","ofa","ofb")]
  assert len(ips)==1,(sn,dn,ips)
  for cell,qp in ((sc,sp),(dc,dp)):
   cfg=cells[cell]["settings"]
   assert cfg.get("CLKMUX")=='"SIG"',(cell,"clock polarity",cfg.get("CLKMUX"))
   assert cfg.get("LATCHMODE")=='"DFF"',(cell,"latch",cfg.get("LATCHMODE"))
   side=qp[-1].upper()
   assert cfg.get("OQ"+side+"MUX")==('"Q'+side+'"'),(cell,qp,cfg)
  pairs.append({"Group":group,"Bit":g.get("Bit"),"SourceQ":sn,"DestinationQ":dn,"SourceCell":sc,"SourcePin":sp,"DestinationCell":dc,"DestinationQPin":dp,"DestinationInput":ips[0],"DestinationRegisterSelection":cells[dc]["settings"].get("REG"+dp[-1].upper()+"_SD"),"DestinationLUTMode":cells[dc]["settings"].get("LUTMODE"),"DestinationInputLogicNote":"Selected output Q is used to bind the source-to-input SDF setuphold. Internal LUT delay is included in the composite setup; no second LUT term is added."})
controls={}
for direct in ("forward","backward"):
 for role in ("request","req_meta","req_sync","acknowledge","ack_meta","ack_sync"):
  net=f"u_p14_pipeline/{direct}/{role}"
  assert len(outputs[net])==1,(net,outputs[net])
  cell,pin=outputs[net][0];controls[f"{direct}/{role}"]={"Cell":cell,"QPin":pin}
for direct in ("forward","backward"):
 for a,b in (("request","req_meta"),("req_meta","req_sync"),("acknowledge","ack_meta"),("ack_meta","ack_sync")):
  sc=controls[f"{direct}/{a}"];dc=controls[f"{direct}/{b}"]
  sn=cells[sc["Cell"]]["ports"][sc["QPin"]]
  ip=[pn for pn,n in cells[dc["Cell"]]["ports"].items() if n==sn and pn not in ("oqa","oqb","ofa","ofb")]
  assert len(ip)==1,(direct,a,b,ip)
  dc["Input"]=ip[0]
def ranges(txt):
 vals=[]
 for body in re.findall(r"\(([^()]*)\)",txt):
  assert re.fullmatch(r"[-+0-9.eE: ]+",body),body
  vec=[float(v) for v in body.split(":") if v.strip()]
  assert len(vec) in (1,3),(body,vec)
  vals.extend(vec)
 assert vals,txt
 return min(vals),max(vals)
def read_sdf(fn):
 p=base/fn
 assert (base/fn.replace(".sdf","-status.tcllist")).read_text().strip()=="STATUS 0 ERROR {}"
 txt=p.read_text()
 assert txt.rstrip().endswith(")")
 header=txt[:txt.index("  (CELL\n")]
 assert "(TIMESCALE 1ps)" in header
 graph={}; rev={}; arcs=collections.defaultdict(list);tim=collections.defaultdict(list);counts=collections.Counter();instances={};cur=""
 for line in txt.splitlines():
  st=line.strip()
  if st.startswith("(INSTANCE "):
   cur=unesc(st[len("(INSTANCE "):-1]);counts["CELL"]+=1;instances[cur]=None
  elif st.startswith("(INTERCONNECT "):
   m=re.fullmatch(r"\(INTERCONNECT (\S+) (\S+) (.+)\)",st);assert m,st
   a,b,dt=m.groups();a=unesc(a);b=unesc(b);v=ranges(dt)
   assert (a,b) not in graph,(a,b)
   graph[(a,b)]=v; rev.setdefault(b,[]).append((a,v)); counts["INTERCONNECT"]+=1
  elif st.startswith("(IOPATH "):
   m=re.fullmatch(r"\(IOPATH (\([^()]+\)|\S+) (\S+) (.+)\)",st);assert m,st
   a,b,dt=m.groups();v=ranges(dt);arcs[cur].append((a,b,v));counts["IOPATH"]+=1
  elif st.startswith("(SETUPHOLD "):
   m=re.fullmatch(r"\(SETUPHOLD (\([^()]+\)|\S+) (\([^()]+\)|\S+) \(([^()]*)\) \(([^()]*)\)\)",st);assert m,st
   dp,cp,su,ho=m.groups();tim[(cur,dp,cp)].append((ranges("("+su+")"),ranges("("+ho+")")));counts["SETUPHOLD"]+=1
  elif st.startswith("(COND ") or st.startswith("(CONDELSE "):
   raise AssertionError(("conditional SDF arc needs evaluation",cur,st))
 def cq(cell,pin):
  v=[v for a,b,v in arcs[cell] if a=="(posedge clk)" and b==pin]
  assert len(v)==1,(cell,pin,v);return v[0]
 def sh(cell,pin):
  v=tim[(cell,pin,"(posedge clk)")]
  assert v,(cell,pin)
  return min(x[0][0] for x in v),max(x[0][1] for x in v),min(x[1][0] for x in v),max(x[1][1] for x in v),len(v)
 def ic(sc,sp,dc,dp):
  k=(sc+"/"+sp,dc+"/"+dp);assert k in graph,k
  return graph[k]
 def clockpath(pin,root,seen=()):
  if pin==root:return []
  assert pin not in seen,("clock loop",pin)
  incoming=rev.get(pin,[])
  if incoming:
   assert len(incoming)==1,("multi driver",pin,incoming)
   a,v=incoming[0]
   return clockpath(a,root,seen+(pin,))+[(a,pin,v)]
  cell,out=pin.rsplit("/",1)
  candidates=[]
  for ip,op,v in arcs[cell]:
   if op==out and not ip.startswith("("):
    try:candidates.append(clockpath(cell+"/"+ip,root,seen+(pin,))+[(cell+"/"+ip,pin,v)])
    except KeyError:pass
    except AssertionError as e:
     if e.args and isinstance(e.args[0],tuple) and e.args[0][0]=="NO_CLOCK_ARC":pass
     else:raise
  assert len(candidates)==1,("NO_CLOCK_ARC",pin,len(candidates),arcs[cell])
  return candidates[0]
 return {"name":fn,"header":header,"sha":hashlib.sha256(p.read_bytes()).hexdigest().upper(),"bytes":p.stat().st_size,"graph":graph,"arcs":arcs,"tim":tim,"counts":counts,"cq":cq,"sh":sh,"ic":ic,"clockpath":clockpath}

roots={"DDR":"u_ph1p35_324_ddr_wrapper/u_ddr2/ph1p_ddrmc_wrapper/ph1p_ddrmc_top/u_ddr_phy/u_ddrphy_top/u_ddrphy_clk/u_pll1/u_bufg_fbclk/clkout","MIPI":"u_mipi_dphy_rx_ph1p_mipiio_wrapper/u_ph1p_mipiio_rx_wrapper/bufg_feedback/clkout","HDMI":"tf_audio/u_file/clk_created_gclkinst/clkout"}
def path_extrema(path):
 return [sum(x[2][0] for x in path),sum(x[2][1] for x in path)]
def skew_upper(a,b):
 common=0
 while common<min(len(a),len(b)) and a[common][:2]==b[common][:2]:
  assert a[common][2]==b[common][2]
  common+=1
 return max(0.0,sum(x[2][1] for x in a[common:])-sum(x[2][0] for x in b[common:]))

def binding(path):
 p=Path(path);b=p.read_bytes()
 return {"Path":str(p).replace("\\","/"),"SHA256":hashlib.sha256(b).hexdigest().upper(),"Bytes":len(b)}
inputs=[base/"routed-netlist.v",audit/"gate-inspection.json",audit/"semantic-review-20261027.json",base/"binding.json",base/"export-result.json",base/"baseline-clocks.tcllist",base/"after-clocks.tcllist",base/"baseline-user.sdc",base/"after-user.sdc",base/"baseline-ip.sdc",base/"after-ip.sdc",base.parent.parent.parent/"r310/route-result.json",base.parent.parent.parent/"r310/td/pl_1/i0309-timing.rpt",base.parent.parent.parent/"u310/td/pl_1/literal-forward-req.rpt",Path(r"E:/juan/FPGA/Data/HX1P35A_Contest_202606/6_PH1P35数据手册/DS1300_PH1P_Datasheet.pdf"),Path(r"D:/Anlogic/TD_6.2.1_Engineer_6.2.168.116/doc/SWUG/SWUG200_Timing_Constraints_User_Guide.pdf"),Path(r"D:/Anlogic/TD_6.2.1_Engineer_6.2.168.116/sim_release/ph1p/ph1p_phy_lslice.v")]
inputs+=[base/x for x in ["slow-lib0.sdf","slow-lib1.sdf","fast-lib0.sdf","fast-lib1.sdf"]]
initial=[binding(p) for p in inputs]
assert (base/"baseline-clocks.tcllist").read_bytes()==(base/"after-clocks.tcllist").read_bytes()
assert (base/"baseline-user.sdc").read_bytes()==(base/"after-user.sdc").read_bytes()
assert (base/"baseline-ip.sdc").read_bytes()==(base/"after-ip.sdc").read_bytes()
result={"At":datetime.now(timezone(timedelta(hours=8))).isoformat(),"Owner":"Codex /root/sdf_audit; parent local/01a17b18-5a45-78b3-83f3-46916f54535a","Status":"独立SDF有界模型审核完成，待Root复核和统一索引闭环","Branch":"task/sc520-system-integration","HEAD":"fe80e3fd4de5e0ade930dafbedf82625f605762d","Unit":"ps","Inputs":initial,"Mappings":pairs,"Controls":controls,"Corners":[]}

for fn in ["slow-lib0.sdf","slow-lib1.sdf","fast-lib0.sdf","fast-lib1.sdf"]:
 r=read_sdf(fn)
 cp={}
 for key,dom in (("forward/request","MIPI"),("forward/req_meta","HDMI"),("forward/acknowledge","HDMI"),("forward/ack_meta","MIPI")):
  cp[key]=r["clockpath"](controls[key]["Cell"]+"/clk",roots[dom])
 req=controls["forward/req_meta"];ack=controls["forward/ack_meta"]
 reqsh=r["sh"](req["Cell"],req["Input"]);acksh=r["sh"](ack["Cell"],ack["Input"])
 ap_req=max(0,reqsh[1])+max(0,reqsh[3]);ap_ack=max(0,acksh[1])+max(0,acksh[3])
 rq0=controls["forward/req_meta"];rq1=controls["forward/req_sync"]
 qc=r["cq"](rq0["Cell"],rq0["QPin"]);qi=r["ic"](rq0["Cell"],rq0["QPin"],rq1["Cell"],rq1["Input"]);qt=r["sh"](rq1["Cell"],rq1["Input"])
 req_cal={"ClockToQPs":qc,"InterconnectPs":qi,"CompositeSetupHoldPs":qt,"SetupRequirementPs":qc[1]+qi[1]+qt[1],"HoldSlackPs":qc[0]+qi[0]-qt[3]}
 co={"CalibrationForwardReqMetaToReqSync":req_cal,"File":fn,"SHA256":r["sha"],"Bytes":r["bytes"],"Header":r["header"],"Counts":r["counts"],"Controls":{"RequestMetaSetupHoldPs":reqsh,"AckMetaSetupHoldPs":acksh,"RequestApertureAllowancePs":ap_req,"AckApertureAllowancePs":ap_ack,"ClockPaths":cp},"ClockPathsByRegisterCell":{},"Rows":[]}
 for p in pairs:
  cq=r["cq"](p["SourceCell"],p["SourcePin"])
  ic=r["ic"](p["SourceCell"],p["SourcePin"],p["DestinationCell"],p["DestinationInput"])
  su0,su1,ho0,ho1,shcount=r["sh"](p["DestinationCell"],p["DestinationInput"])
  assert shcount==1,(fn,p,shcount)
  row={"SourceQ":p["SourceQ"],"DestinationQ":p["DestinationQ"],"Group":p["Group"],"Bit":p["Bit"],"ClockToQPs":cq,"InterconnectPs":ic,"DestinationCompositeSetupPs":[su0,su1],"DestinationCompositeHoldPs":[ho0,ho1],"ExternalDataMinPs":cq[0]+ic[0],"ExternalDataMaxPs":cq[1]+ic[1],"DataPlusCompositeSetupMaxPs":cq[1]+ic[1]+max(0,su1)}
  if p["Group"]=="ForwardRetainedPairs":
   ps=r["clockpath"](p["SourceCell"]+"/clk",roots["MIPI"]);pd=r["clockpath"](p["DestinationCell"]+"/clk",roots["HDMI"])
   co["ClockPathsByRegisterCell"][p["SourceCell"]]=ps;co["ClockPathsByRegisterCell"][p["DestinationCell"]]=pd
   pen1=skew_upper(ps,cp["forward/request"]);pen2=skew_upper(cp["forward/req_meta"],pd)
   holdp1=skew_upper(pd,cp["forward/acknowledge"]);holdp2=skew_upper(cp["forward/ack_meta"],ps)
   residual=26666-row["DataPlusCompositeSetupMaxPs"]-pen1-pen2
   hold_residual=19320+cq[0]+ic[0]-max(0,ho1)-holdp1-holdp2
   row.update({"SourceClockLeafPs":path_extrema(ps),"DestinationClockLeafPs":path_extrema(pd),"SourceSkewPenaltyPs":pen1,"DestinationSkewPenaltyPs":pen2,"ResidualJPlusAPs":residual,"RequestApertureAllowancePs":ap_req,"J2TModelPs":254,"SetupModelMarginPs":residual-ap_req-254,"HoldDestinationSkewPenaltyPs":holdp1,"HoldSourceSkewPenaltyPs":holdp2,"HoldResidualJPlusAPs":hold_residual,"AckApertureAllowancePs":ap_ack,"HoldJ2TModelPs":150,"HoldModelMarginPs":hold_residual-ap_ack-150})
  else:
   budget=9360 if p["SourceQ"].startswith("u_video_in/") else 13033
   is_in=p["SourceQ"].startswith("u_video_in/")
   read_cross="/rd_to_wr_cross_inst/" in p["SourceQ"]
   source_domain=("DDR" if read_cross else "MIPI") if is_in else ("HDMI" if read_cross else "DDR")
   destination_domain=("MIPI" if read_cross else "DDR") if is_in else ("DDR" if read_cross else "HDMI")
   gs=r["clockpath"](p["SourceCell"]+"/clk",roots[source_domain]);gd=r["clockpath"](p["DestinationCell"]+"/clk",roots[destination_domain])
   co["ClockPathsByRegisterCell"][p["SourceCell"]]=gs;co["ClockPathsByRegisterCell"][p["DestinationCell"]]=gd
   leaf=path_extrema(gs)
   row.update({"SourceClockDomain":source_domain,"DestinationClockDomain":destination_domain,"SourceClockLeafPs":leaf,"DestinationClockLeafPs":path_extrema(gd),"SourceRootToDataInputArrivalPs":[leaf[0]+cq[0]+ic[0],leaf[1]+cq[1]+ic[1]]})
   row.update({"OriginalIPBudgetPs":budget,"ConservativeIPBudgetMarginPs":budget-row["DataPlusCompositeSetupMaxPs"]})
  co["Rows"].append(row)
 bundles=[x for x in co["Rows"] if x["Group"]=="ForwardRetainedPairs"];grays=[x for x in co["Rows"] if x["Group"]=="GrayPairs"]
 summ={"BundledCount":len(bundles),"GrayCount":len(grays),"MaxBundleTotalPs":max(x["DataPlusCompositeSetupMaxPs"] for x in bundles),"MinSetupModelMargin":min(bundles,key=lambda x:x["SetupModelMarginPs"]),"MinHoldModelMargin":min(bundles,key=lambda x:x["HoldModelMarginPs"]),"MinGrayConservativeBudgetMargin":min(grays,key=lambda x:x["ConservativeIPBudgetMarginPs"])}
 # Keep full endpoint expansion in rows; summary uses scalar extrema and names.
 for key in ["MinSetupModelMargin","MinHoldModelMargin","MinGrayConservativeBudgetMargin"]:
  summ[key]={k:v for k,v in summ[key].items() if not k.endswith("ClockPath")}
 
 gray_buses=collections.defaultdict(list)
 for row in grays:gray_buses[row["SourceQ"].rsplit("/",1)[0]].append(row)
 co["GrayBusArrivalSpans"]=[]
 for scope,rr in gray_buses.items():
  assert len(rr)==9
  early=min(rr,key=lambda x:x["SourceRootToDataInputArrivalPs"][0])
  late=max(rr,key=lambda x:x["SourceRootToDataInputArrivalPs"][1])
  span=late["SourceRootToDataInputArrivalPs"][1]-early["SourceRootToDataInputArrivalPs"][0]
  co["GrayBusArrivalSpans"].append({"Scope":scope,"Count":len(rr),"EarliestSourceQ":early["SourceQ"],"LatestSourceQ":late["SourceQ"],"EarliestArrivalPs":early["SourceRootToDataInputArrivalPs"][0],"LatestArrivalPs":late["SourceRootToDataInputArrivalPs"][1],"ConservativeArrivalSpanPs":span,"OriginalIPBudgetPs":rr[0]["OriginalIPBudgetPs"],"SpanBudgetMarginPs":rr[0]["OriginalIPBudgetPs"]-span,"Note":"Arrival spread uses a common source GCLK root; includes source clock leaf skew plus CLK-to-Q and interconnect. No subtraction across asynchronous clocks."})
 co["Summary"]=summ
 result["Corners"].append(co)

assert result["Corners"][1]["CalibrationForwardReqMetaToReqSync"]["SetupRequirementPs"]==545
assert result["Corners"][3]["CalibrationForwardReqMetaToReqSync"]["HoldSlackPs"]==151
# Binding integrity is checked after every SDF corner has been consumed.
final=[binding(p) for p in inputs]
assert initial==final,"An audit input changed while being read"
assert all(c["Summary"]["BundledCount"]==166 and c["Summary"]["GrayCount"]==36 for c in result["Corners"])
assert all(r["SetupModelMarginPs"]>0 and r["HoldModelMarginPs"]>0 for c in result["Corners"] for r in c["Rows"] if r["Group"]=="ForwardRetainedPairs")
assert all(r["ConservativeIPBudgetMarginPs"]>0 for c in result["Corners"] for r in c["Rows"] if r["Group"]=="GrayPairs")
assert all(b["SpanBudgetMarginPs"]>0 for c in result["Corners"] for b in c["GrayBusArrivalSpans"])
result["Coverage"]={"ForwardLogicalWidth":240,"RetainedPhysicalPairs":166,"ConstantZeroLogicalBits":39,"EquivalentLogicalBits":35,"SemanticClosureSource":"semantic-review-20261027.json; routed alias/constant independent review remains a separately bound Root check","GrayPhysicalPairs":36,"Corners":4,"ForwardCornerChecks":664,"GrayCornerChecks":144,"ForwardAndGrayUniquePhysicalQDriverChecks":404,"AllForwardAndGrayDestinationInputsDirect":True,"MissingDataOrTimingArcs":0,"MissingClockPaths":0,"AllAuditInputsUnchanged":True,"AllTargetClockMuxes":"SIG","AllTargetLatches":"DFF"}
result["Method"]={
"ForwardSetup":"CQmax + INTERCONNECTmax + max(0,composite_setup) + max(0,Lheld_late-Lrequest_early) + max(0,Lreqmeta_late-Ldst_early) + J2T + Areq < 26666 ps.",
"ForwardHold":"19320 ps + CQmin + INTERCONNECTmin - max(0,composite_hold) - max(0,Ldst_late-Lack_early) - max(0,Lackmeta_late-Lheld_early) - J2T_src - Aack > 0.",
"LeafDifference":"Clock paths start at each domain's common physical GCLK output. Only exactly identical shared static path edges are cancelled, then late/early branch envelopes are subtracted. No phase relation is assumed between MIPI/HDMI/DDR.",
"PayloadHoldRationale":"RTL consumes at E2 after req_meta first captures E0. Acknowledge is written at the consume edge; source ack_meta, ack_sync and nonblocking src_ready use require two source periods before earliest overwrite. Request/ack transport delay is not credited.",
"Aperture":"For the actual req_meta/ack_meta input, allowance=max(0,composite_setup_max)+max(0,composite_hold_max) in each SDF corner. This overbounds the characterized timing window; it is not a metastability MTBF measurement. Correct synchronizer resolution is an explicit design assumption.",
"CompositeEndpoint":"SDF SETUPHOLD at the physical slice data input already includes its internal LUT delay plus FF setup. Negative composite hold values are retained; bundle hold proof clamps them to zero conservatively. Setup and hold calibration uses the same physical req_meta(QA)/req_sync(QB) packed slice, not names alone.",
"SDFBounds":"Every listed triplet min/typ/max and exported edge delay is enveloped. Conditional arcs cause a hard failure. Every target must have unique CQ, interconnect and setuphold coverage. Four corners are slow/fast x 125/-40 C, all headers 1.10 V and 1 ps.",
"Gray":"Each registered Gray-Q to actual sync_r1 physical input is checked with CQ+interconnect+composite setup against original min(Twr,Trd)-0.3 ns budget (18 at9.360ns,18 at13.033ns). Also check common-source-root bus arrival spans for each nine-bit bus.",
"Calibration":"slow_m40 req chain CQ126 + wire201 + composite setup218 = 545 ps = native data481 + internal FF setup64 = 2000 - slack1455. fast_m40 CQmin + wiremin - composite hold =151 ps = native data163 - internal FF hold12. The get_path_delay headers without values are excluded.",
"NativeBaseline":"r310 complete original constraints Routed/Both SWNS+0.010/HWNS+0.020/TNS0 are separate evidence; u312 preserved all15 get_clocks objects and byte-identical before/after user/IP constraints. Failed default20ns views are not used."}
result["UncertaintyModel"]={"Status":"候选模型筛查假设，非板上实测或原厂输出抖动上限","HDMIReportedSetupUncertaintyNs":[0.102,0.127],"MIPIReportedSetupUncertaintyNs":[0.050,0.075],"UserSdcUncertaintyNs":0,"ForwardJ2TModelNs":0.254,"HoldSourceJ2TModelNs":0.150,"Derivation":"Twice the largest currently reported same-domain TD default setup uncertainty; explicitly accepted by Root for first SRAM candidate model screening. This does not establish a physical two-cycle jitter bound.","FormalCondition":"For each row, actual J2T+Areq must be below ResidualJPlusAPs, and actual source J2T+Aack below HoldResidualJPlusAPs.","DatasheetFindings":["DS1300_1.2(2025.08), PDF76–79/body70–73: PH1P35 GCLK skew0.24ns is a generic spec and is not substituted for routed leaf sums.","Table3-45: current FIN50MHz/REFCLK_DIV1 PLL accepts input jitter1000ps p-p for10<=fPFD<100MHz; this is an input tolerance, not an output two-period jitter bound.0.1ns denotes static phase offset between equal-phase output channels.","Table3-46 CLOCK ALIGNER input100ps/output increment50ps at50–100MHz concerns a different block and is not applied to current PH1P_PHY_PLL_V2.","Table3-45 phase-noise points and input-jitter tolerance alone do not provide a deterministic current-output J2T bound.","SWUG200 PDF10/body2: primary-clock uncertainty is not propagated to generated clocks. PDF55/body47: user uncertainty is extra margin and does not override default jitter calculation."]}
result["Qualification"]={"BoundedCandidateCDCModelPass":True,"OriginalIPGrayBudgetScreenPass":True,"AbsoluteMetastabilityGuaranteeClaimed":False,"PhysicalClockJitterMeasured":False,"WholeDevicePhysicalSignoff":False,"BitgenAllowedByThisReport":False,"HardwareValidated":False,"DecisionOwner":"Root","Remaining":["Root independent review of exact script/report/input bindings and routed240-bit optimization closure; shared index batch completion.","Two-cycle physical jitter is not measured here; FPGA SRAM candidate screen is distinct from final board/system qualification.","Common reset assertion/local release and global unrelated CDC/external interface timing remain under their separate audits; this report only covers166 forward payload and36Gray crossings plus relevant req/ack timing.","Bit generation, download and SRAM test are separate Root decisions; no such operation is performed by this script."]}
result["Reproduction"]={"Command":"python -I -B E:/juan/FPGA/learning/sc520-system-integration/physical-review/i0309-final/sdf-bounded-review.py","WriteCommandAdds":"--write-report (creates a new report only; default is read-only)","AuthorScript":binding(Path(__file__)),"StdoutTruncationHistory":"One prior pure in-memory full JSON print completed code0 but tool stdout was truncated at approximately1MiB. No artifact from that truncated stdout was accepted. This script writes the complete JSON and prints only compact summaries."}
summary=[{"File":c["File"],"BundleMaxNs":c["Summary"]["MaxBundleTotalPs"]/1000,"SetupMinMarginNs":c["Summary"]["MinSetupModelMargin"]["SetupModelMarginPs"]/1000,"HoldMinMarginNs":c["Summary"]["MinHoldModelMargin"]["HoldModelMarginPs"]/1000,"GrayMinMarginNs":c["Summary"]["MinGrayConservativeBudgetMargin"]["ConservativeIPBudgetMarginPs"]/1000,"GrayMaxSpanNs":max(b["ConservativeArrivalSpanPs"] for b in c["GrayBusArrivalSpans"])/1000} for c in result["Corners"]]
if "--write-report" in sys.argv:
 report_path=audit/"sdf-bounded-review-20261027.json"
 with report_path.open("x",encoding="utf-8",newline="\n") as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write("\n")
 print("REPORT",json.dumps(binding(report_path),ensure_ascii=False))
print(json.dumps({"Coverage":result["Coverage"],"Summary":summary,"Qualification":result["Qualification"]},ensure_ascii=False,indent=2))


